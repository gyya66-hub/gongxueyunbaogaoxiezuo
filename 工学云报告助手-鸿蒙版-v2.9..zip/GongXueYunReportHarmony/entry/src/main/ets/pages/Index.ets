import { common, Want } from '@kit.AbilityKit';
import { pasteboard, BusinessError } from '@kit.BasicServicesKit';
import { mediaquery } from '@kit.ArkUI';
import { util } from '@kit.ArkTS';
import { preferences } from '@kit.ArkData';
import { fileIo, picker } from '@kit.CoreFileKit';
import { ContentPack, ItemDef, Config, Engine } from '../model/Engine';

const LANGS: string[] = ['zh', 'zh-Hant', 'en', 'ru', 'ja', 'ko'];
const LANG_LABELS: string[] = ['简体中文', '繁體中文', 'English', 'Русский', '日本語', '한국어'];
const GXY_URL: string = 'https://p3.gongxueyun.com/login';

@Entry
@Component
struct Index {
  @State pack: ContentPack | null = null;
  @State lang: string = 'zh';
  @State themeMode: number = 0;
  @State sysDark: boolean = false;
  @State monthly: boolean = false;
  @State periodIndex: number = 1;
  @State unit: string = '某某汽车科技有限公司';
  @State post: string = '汽车制造辅助岗';
  @State selected: string[] = ['observe', 'assemble', 'inspect'];
  @State report: string = '';
  @State notice: string = '';
  @State wide: boolean = false;
  @State history: string[] = [];
  @State msgs: string[] = [];
  @State msgText: string = '';

  @State editedTip: string = '';

  private ctx: common.UIAbilityContext = getContext(this) as common.UIAbilityContext;
  private darkMq: mediaquery.MediaQueryListener = mediaquery.matchMediaSync('(dark-mode: true)');
  private wideMq: mediaquery.MediaQueryListener = mediaquery.matchMediaSync('(width>=600vp)');

  aboutToAppear(): void {
    this.sysDark = this.darkMq.matches;
    this.darkMq.on('change', (r: mediaquery.MediaQueryResult) => {
      this.sysDark = r.matches;
    });
    this.wide = this.wideMq.matches;
    this.wideMq.on('change', (r: mediaquery.MediaQueryResult) => {
      this.wide = r.matches;
    });
    this.loadPack();
    this.loadHistory();
    this.loadMsgs();
  }

  private async loadPack(): Promise<void> {
    try {
      let buf: Uint8Array = await this.ctx.resourceManager.getRawFileContent(Engine.fileOf(this.lang));
      let dec: util.TextDecoder = util.TextDecoder.create('utf-8');
      let text: string = dec.decodeToString(buf);
      this.pack = JSON.parse(text) as ContentPack;
    } catch (e) {
      this.notice = '内容库加载失败：' + String(e);
    }
  }

  private periodOptions(): SelectOption[] {
    let out: SelectOption[] = [];
    for (let n = 1; n <= 12; n++) {
      out.push({ value: this.monthly ? '第 ' + n + ' 个月' : '第 ' + n + ' 周' });
    }
    return out;
  }

  private isDark(): boolean {
    if (this.themeMode === 0) {
      return this.sysDark;
    }
    return this.themeMode === 2;
  }

  private textColor(): string {
    return this.isDark() ? '#E9EEF7' : '#1B2430';
  }

  private subColor(): string {
    return this.isDark() ? '#93A1B5' : '#66748A';
  }

  private cardBg(): string {
    return this.isDark() ? '#1C2431CC' : '#FFFFFFCC';
  }

  private fieldBg(): string {
    return this.isDark() ? '#FFFFFF14' : '#FFFFFFF2';
  }

  private toggleItem(id: string): void {
    let i: number = this.selected.indexOf(id);
    if (i >= 0) {
      this.selected.splice(i, 1);
    } else {
      if (this.selected.length >= 8) {
        this.notice = '最多勾选 8 项，太多了正文会变成罗列';
        return;
      }
      this.selected.push(id);
      this.notice = '';
    }
  }

  private wordTip(): string {
    let n: number = Engine.charCount(this.report);
    if (n === 0) {
      return '0 字';
    }
    let lo: number = this.monthly ? 1100 : 850;
    let hi: number = this.monthly ? 1300 : 950;
    let tip: string = n < lo ? '偏短，建议再生成一版' : (n > hi ? '偏长，可手动删减' : '字数合适');
    if (this.editedTip.length > 0) {
      tip = this.editedTip;
    }
    return n.toString() + ' 字 · ' + tip;
  }

  private doGenerate(): void {
    if (this.pack === null) {
      this.notice = '内容库还没加载好，稍等一下再试';
      return;
    }
    if (this.unit.trim().length === 0 || this.post.trim().length === 0) {
      this.notice = '实习单位和岗位不要留空，学校可能会核对';
      return;
    }
    let c: Config = new Config();
    c.unit = this.unit;
    c.post = this.post;
    c.name = '';
    c.monthly = this.monthly;
    c.index = this.periodIndex;
    c.itemIds = this.selected.slice(0);
    this.report = Engine.generate(this.pack as ContentPack, c);
    this.notice = '';
  }

  private async copy(): Promise<void> {
    if (this.report.length === 0) {
      this.notice = '先点「生成并复制」';
      return;
    }
    try {
      let data: pasteboard.PasteData =
        pasteboard.createData(pasteboard.MIMETYPE_TEXT_PLAIN, this.report);
      await pasteboard.getSystemPasteboard().setData(data);
      this.notice = '已复制，去工学云长按粘贴即可';
    } catch (e) {
      this.notice = '复制失败：' + String(e);
    }
  }

  private openGxy(): void {
    let want: Want = { action: 'ohos.want.action.viewData', uri: GXY_URL };
    this.ctx.startAbility(want).catch((e: BusinessError) => {
      this.notice = '打开工学云失败：' + e.message;
    });
  }

  private async loadMsgs(): Promise<void> {
    try {
      let pf: preferences.Preferences = await preferences.getPreferences(this.ctx, 'gxy');
      let raw: string = await pf.get('msgs', '[]') as string;
      this.msgs = JSON.parse(raw) as string[];
    } catch (e) {
      this.msgs = [];
    }
  }

  private async addMsg(): Promise<void> {
    let v: string = this.msgText.trim();
    if (v.length === 0) {
      this.notice = '先写点内容再保存';
      return;
    }
    let stamp: string = new Date().toLocaleString();
    let list: string[] = this.msgs.slice(0);
    list.unshift(stamp + ' | ' + v);
    if (list.length > 50) {
      list = list.slice(0, 50);
    }
    this.msgs = list;
    this.msgText = '';
    try {
      let pf: preferences.Preferences = await preferences.getPreferences(this.ctx, 'gxy');
      await pf.put('msgs', JSON.stringify(list));
      await pf.flush();
      this.notice = '留言已保存到本机';
    } catch (e) {
      this.notice = '保存失败：' + String(e);
    }
  }

  private async clearMsgs(): Promise<void> {
    this.msgs = [];
    try {
      let pf: preferences.Preferences = await preferences.getPreferences(this.ctx, 'gxy');
      await pf.put('msgs', '[]');
      await pf.flush();
      this.notice = '留言已清空';
    } catch (e) {
      this.notice = '清空失败：' + String(e);
    }
  }

  private async loadHistory(): Promise<void> {
    try {
      let pf: preferences.Preferences = await preferences.getPreferences(this.ctx, 'gxy');
      let raw: string = await pf.get('hist', '[]') as string;
      let arr: string[] = JSON.parse(raw) as string[];
      this.history = arr;
    } catch (e) {
      this.history = [];
    }
  }

  private async saveHistory(text: string): Promise<void> {
    let list: string[] = this.history.slice(0);
    list.unshift(text);
    if (list.length > 8) {
      list = list.slice(0, 8);
    }
    this.history = list;
    try {
      let pf: preferences.Preferences = await preferences.getPreferences(this.ctx, 'gxy');
      await pf.put('hist', JSON.stringify(list));
      await pf.flush();
    } catch (e) {
      this.notice = '历史保存失败：' + String(e);
    }
  }

  private async clearHistory(): Promise<void> {
    this.history = [];
    try {
      let pf: preferences.Preferences = await preferences.getPreferences(this.ctx, 'gxy');
      await pf.put('hist', '[]');
      await pf.flush();
      this.notice = '历史已清空';
    } catch (e) {
      this.notice = '清空失败：' + String(e);
    }
  }

  private async exportTxt(): Promise<void> {
    if (this.report.length === 0) {
      this.notice = '先生成一份报告再导出';
      return;
    }
    try {
      const opt: picker.DocumentSaveOptions = new picker.DocumentSaveOptions();
      opt.newFileNames = ['工学云报告-' + Date.now().toString() + '.txt'];
      const p: picker.DocumentViewPicker = new picker.DocumentViewPicker(this.ctx);
      const uris: string[] = await p.save(opt);
      if (uris.length === 0) {
        return;
      }
      let f = fileIo.openSync(uris[0], fileIo.OpenMode.READ_WRITE | fileIo.OpenMode.CREATE);
      fileIo.writeSync(f.fd, this.report);
      fileIo.closeSync(f);
      this.notice = '已导出为 txt';
    } catch (e) {
      this.notice = '导出失败：' + String(e);
    }
  }

  private async generateAndCopy(): Promise<void> {
    this.doGenerate();
    if (this.report.length > 0) {
      await this.copy();
      await this.saveHistory(this.report);
    }
  }

  private async generateAndOpen(): Promise<void> {
    this.doGenerate();
    await this.copy();
    this.openGxy();
  }

  @Builder
  chip(label: string, on: boolean, action: () => void) {
    Text(label)
      .fontSize(13)
      .fontColor(on ? '#FFFFFF' : this.textColor())
      .padding({ left: 14, right: 14, top: 7, bottom: 7 })
      .backgroundColor(on ? '#2F6DF6' : this.fieldBg())
      .borderRadius(16)
      .margin({ right: 8, bottom: 8 })
      .onClick(action)
  }

  @Builder
  segButton(label: string, on: boolean, action: () => void) {
    Text(label)
      .fontSize(13)
      .fontColor(on ? '#FFFFFF' : this.textColor())
      .textAlign(TextAlign.Center)
      .layoutWeight(1)
      .padding({ top: 9, bottom: 9 })
      .backgroundColor(on ? '#2F6DF6' : this.fieldBg())
      .borderRadius(10)
      .onClick(action)
  }

  @Builder
  sectionTitle(t: string) {
    Row() {
      Text(t).fontSize(14).fontColor(this.subColor()).fontWeight(FontWeight.Medium)
      Blank()
    }.width('100%').margin({ bottom: 8 })
  }

  @Builder
  panel() {
    Scroll() {
      Column() {
        this.sectionTitle('报告类型')
        Row({ space: 8 }) {
          this.segButton('周报', !this.monthly, () => { this.monthly = false; })
          this.segButton('月报', this.monthly, () => { this.monthly = true; })
        }.width('100%').margin({ bottom: 14 })

        this.sectionTitle(this.monthly ? '第几个月' : '第几周')
        Select(this.periodOptions())
          .selected(this.periodIndex - 1)
          .value(this.monthly ? '第 ' + this.periodIndex + ' 个月' : '第 ' + this.periodIndex + ' 周')
          .fontColor(this.textColor())
          .backgroundColor(this.fieldBg())
          .width('100%')
          .onSelect((i: number) => { this.periodIndex = i + 1; })
          .margin({ bottom: 14 })

        this.sectionTitle('实习单位')
        TextInput({ text: this.unit, placeholder: '例如：某某汽车科技有限公司' })
          .fontColor(this.textColor())
          .backgroundColor(this.fieldBg())
          .width('100%')
          .margin({ bottom: 14 })
          .onChange((v: string) => { this.unit = v; })

        this.sectionTitle('实习岗位')
        TextInput({ text: this.post, placeholder: '例如：汽车制造辅助岗' })
          .fontColor(this.textColor())
          .backgroundColor(this.fieldBg())
          .width('100%')
          .margin({ bottom: 14 })
          .onChange((v: string) => { this.post = v; })

        Row() {
          Text('工作内容').fontSize(14).fontColor(this.subColor())
          Blank()
          Text('已选 ' + this.selected.length + ' 项').fontSize(12).fontColor(this.subColor())
        }.width('100%').margin({ bottom: 8 })

        Flex({ wrap: FlexWrap.Wrap }) {
          ForEach((this.pack?.items ?? []) as ItemDef[], (it: ItemDef) => {
            this.chip(it.name, this.selected.indexOf(it.id) >= 0, () => { this.toggleItem(it.id); })
          }, (it: ItemDef) => it.id)
        }.width('100%')

        if (this.history.length > 0) {
          Row() {
            Text('历史记录').fontSize(14).fontColor(this.subColor())
            Blank()
            Text('清空').fontSize(12).fontColor('#2F6DF6')
              .onClick(() => { this.clearHistory(); })
          }.width('100%').margin({ top: 14, bottom: 8 })

          ForEach(this.history, (t: string, i: number) => {
            Text(t.split('
')[0])
              .fontSize(12.5)
              .fontColor(this.textColor())
              .maxLines(1)
              .textOverflow({ overflow: TextOverflow.Ellipsis })
              .width('100%')
              .padding(10)
              .backgroundColor(this.fieldBg())
              .borderRadius(10)
              .margin({ bottom: 6 })
              .onClick(async () => {
                this.report = t;
                await this.copy();
                this.notice = '已载入并复制';
              })
          }, (t: string, i: number) => i.toString() + t.length.toString())
        }
        Divider().color(this.textColor()).opacity(0.12).margin({ top: 16, bottom: 12 })

        Row() {
          Text('反馈群（QQ）').fontSize(14).fontColor(this.subColor())
          Blank()
          Text('1121018207　点击复制').fontSize(12).fontColor('#2F6DF6')
            .onClick(async () => {
              let data = pasteboard.createData(pasteboard.MIMETYPE_TEXT_PLAIN, '1121018207');
              await pasteboard.getSystemPasteboard().setData(data);
              try {
                let want: Want = {
                  action: 'ohos.want.action.viewData',
                  uri: 'mqqapi://card/show_pslcard?src_type=internal&version=1&uin=1121018207&card_type=group&source=qrcode'
                };
                this.ctx.startAbility(want);
                this.notice = '正在打开 QQ…';
              } catch (e) {
                this.notice = '群号已复制：1121018207，去 QQ 搜索「工学云周报月报打卡交流群」';
              }
            })
        }.width('100%').margin({ top: 14, bottom: 4 })

        Row() {
          Text('留言板').fontSize(14).fontColor(this.subColor())
          Blank()
          Text('清空').fontSize(12).fontColor('#2F6DF6')
            .onClick(() => { this.clearMsgs(); })
        }.width('100%')

        Text('写使用反馈、建议或遇到的问题。只存本机，不上传；想让我看到，加下面的 QQ 群。')
          .fontSize(11.5).fontColor(this.subColor()).width('100%').margin({ top: 4, bottom: 8 })

        TextArea({ text: this.msgText, placeholder: '例如：第 12 周的涂装车间那段，能不能加一项前处理检查？' })
          .fontSize(14)
          .fontColor(this.textColor())
          .backgroundColor(this.fieldBg())
          .borderRadius(12)
          .height(84)
          .width('100%')
          .onChange((v: string) => { this.msgText = v; })

        Row() {
          Text('保存留言').fontSize(13).fontColor('#FFFFFF')
            .padding({ left: 16, right: 16, top: 8, bottom: 8 })
            .backgroundColor('#2F6DF6').borderRadius(14)
            .onClick(() => { this.addMsg(); })
          Blank()
          Text('共 ' + this.msgs.length.toString() + ' 条').fontSize(11.5).fontColor(this.subColor())
        }.width('100%').margin({ top: 10, bottom: 6 })

        ForEach(this.msgs, (m: string, i: number) => {
          Row() {
            Text(m.split(' | ')[1] ?? m)
              .fontSize(12.5).fontColor(this.textColor()).layoutWeight(1)
              .maxLines(3).textOverflow({ overflow: TextOverflow.Ellipsis })
            Text('删').fontSize(11).fontColor(this.subColor()).margin({ left: 8 })
              .onClick(async () => {
                let list: string[] = this.msgs.slice(0);
                list.splice(i, 1);
                this.msgs = list;
                let pf: preferences.Preferences = await preferences.getPreferences(this.ctx, 'gxy');
                await pf.put('msgs', JSON.stringify(list));
                await pf.flush();
              })
          }
          .width('100%').padding(10).backgroundColor(this.fieldBg()).borderRadius(10).margin({ bottom: 6 })
        }, (m: string, i: number) => i.toString() + m.length.toString())
      }
      .padding(16)
      .width('100%')
    }
    .scrollBar(BarState.Off)
  }

  @Builder
  resultPanel() {
    Column() {
      Row({ space: 8 }) {
        this.segButton('生成并复制', false, () => { this.generateAndCopy(); })
        this.segButton('生成并打开工学云', false, () => { this.generateAndOpen(); })
      }.width('100%')

      Row() {
        Text('复制全文').fontSize(13).fontColor(this.textColor())
          .padding({ left: 12, right: 12, top: 7, bottom: 7 })
          .backgroundColor(this.fieldBg()).borderRadius(14)
          .onClick(() => { this.copy(); })
        Text('导出 TXT').fontSize(13).fontColor(this.textColor())
          .padding({ left: 12, right: 12, top: 7, bottom: 7 })
          .backgroundColor(this.fieldBg()).borderRadius(14)
          .margin({ left: 8 })
          .onClick(() => { this.exportTxt(); })
        Text('换一版').fontSize(13).fontColor(this.textColor())
          .padding({ left: 12, right: 12, top: 7, bottom: 7 })
          .backgroundColor(this.fieldBg()).borderRadius(14)
          .margin({ left: 8 })
          .onClick(() => { this.doGenerate(); })
        Blank()
        Text(this.wordTip()).fontSize(11).fontColor(this.subColor())
      }.width('100%').margin({ top: 10, bottom: 8 })

      if (this.notice.length > 0) {
        Text(this.notice).fontSize(11).fontColor('#FF9F43').margin({ bottom: 8 })
      }

      TextArea({ text: this.report, placeholder: '点「生成并复制」，正文会自动出现在这里并复制到剪贴板，直接去工学云粘贴提交即可。' })
        .fontSize(14)
        .fontColor(this.textColor())
        .backgroundColor(this.fieldBg())
        .borderRadius(14)
        .layoutWeight(1)
        .width('100%')
        .onChange((v: string) => { this.report = v; })
    }
    .layoutWeight(1)
    .height('100%')
  }

  @Builder
  topBar() {
    Row() {
      Column() {
        Text('工学云报告助手').fontSize(17).fontWeight(FontWeight.Bold).fontColor(this.textColor())
        Text('离线生成 · 一键复制 · 手机 / 电脑 / 网页同一套界面').fontSize(11).fontColor(this.subColor())
      }.alignItems(HorizontalAlign.Start)
      Blank()
      Text(this.themeMode === 0 ? '跟随系统' : (this.themeMode === 1 ? '浅色' : '深色'))
        .fontSize(12).fontColor('#2F6DF6')
        .padding({ left: 12, right: 12, top: 6, bottom: 6 })
        .backgroundColor(this.fieldBg()).borderRadius(12)
        .onClick(() => { this.themeMode = (this.themeMode + 1) % 3; })
    }
    .width('100%')
    .padding({ left: 16, right: 16, top: 10, bottom: 10 })
    .backgroundColor(this.cardBg())
  }

  build() {
    Stack({ alignContent: Alignment.TopStart }) {
      Image(this.isDark() ? $r('app.media.bg_dark_ai') : $r('app.media.bg_light_ai'))
        .width('100%').height('100%').objectFit(ImageFit.Cover)
      Column() {
        this.topBar()
        Flex({ wrap: FlexWrap.Wrap }) {
          ForEach(LANGS, (lg: string, i: number) => {
            this.chip(LANG_LABELS[i], this.lang === lg, async () => {
              this.lang = lg;
              await this.loadPack();
              this.notice = '';
            })
          }, (lg: string) => lg)
        }
        .width('100%')
        .padding({ left: 16, right: 16, top: 8, bottom: 2 })

        if (this.wide) {
          Row({ space: 12 }) {
            Column() { this.panel() }
              .width(360)
              .layoutWeight(0)
              .backgroundColor(this.cardBg())
              .borderRadius(20)
              .backdropBlur(18)
              .height('100%')
            Column() { this.resultPanel() }
              .layoutWeight(1)
              .backgroundColor(this.cardBg())
              .borderRadius(20)
              .backdropBlur(18)
              .height('100%')
              .padding(14)
          }
          .layoutWeight(1)
          .padding({ left: 16, right: 16, top: 8, bottom: 16 })
          .width('100%')
        } else {
          Column({ space: 10 }) {
            Column() { this.panel() }
              .backgroundColor(this.cardBg())
              .borderRadius(20)
              .backdropBlur(18)
              .constraintSize({ maxHeight: '56%' })
            Column() { this.resultPanel() }
              .backgroundColor(this.cardBg())
              .borderRadius(20)
              .backdropBlur(18)
              .layoutWeight(1)
              .padding(14)
          }
          .layoutWeight(1)
          .padding({ left: 13, right: 13, top: 8, bottom: 14 })
        }
      }
      .width('100%')
      .height('100%')
    }
    .width('100%')
    .height('100%')
  }
}
