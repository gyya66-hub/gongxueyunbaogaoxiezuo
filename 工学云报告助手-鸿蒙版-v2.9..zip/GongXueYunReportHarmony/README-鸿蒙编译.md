# 工学云报告助手 · 鸿蒙版（HarmonyOS NEXT / 5.0）

ArkTS 原生工程，支持手机、平板、2in1 设备，功能与安卓 v2.2 对齐。

## 怎么跑起来（DevEco Studio）
1. 装 **DevEco Studio 5.0**（官网 developer.huawei.com → 下载 → 一路下一步，SDK 会自动装）
2. File → Open → 选本文件夹 `GongXueYunReportHarmony`，等它 Sync 完（第一次约 3–5 分钟）
3. **签名**：File → Project Structure → Signing Configs → 勾选 **Automatically generate signature**
   （需要登录华为账号，免费；会自动生成调试证书）
4. 连上鸿蒙手机（开发者模式 + USB 调试），点绿色三角 Run
5. 或 Build → Build Hap(s) → 产物在 `entry/build/default/outputs/default/entry-default-signed.hap`

## 装到手机上
- DevEco 直接 Run 最省事
- 已签名 hap 可用 `hdc install xxx.hap` 或华为手机「文件管理」点击安装（需允许安装未知来源应用）

## 已实现（v2.5，与安卓一致）
- 周报 / 月报，期数 1–12
- 工作内容 22 项，上限 8 项
- 五语言（简/繁/英/俄/日），点语言即换整套文案
- 双主题（跟随系统 / 浅色 / 深色），背景用 AI 插画深浅两套
- 生成 → 自动复制剪贴板 → 一键跳转工学云登录页
- 字数提示（周报 850–950，月报 1100–1300）
- 平板/2in1 宽度 ≥600vp 自动左右双栏
- 正文可直接编辑
- 历史记录（最近 8 条，点击重新载入并复制）
- 导出 txt（系统文件选择器，存到手机任意目录）
- 去掉姓名输入，标题不再带署名
- 分层图标（background + foreground），深色/浅色桌面都正常

## 与安卓的差异
- 鸿蒙 NEXT 不兼容 apk，所以必须是原生 ArkTS 工程
- 未做「分享到微信」（鸿蒙 Share Kit 需申请权限，未接；可用复制代替）
- 未接在线更新（鸿蒙应用更新走应用市场）

## 说明
本工程未在真机 DevEco 里编译验证过（生成环境无 HarmonyOS SDK）。
首次 Sync/编译若报错，把报错行发我，我按错误修。
