package com.lc.reporthelper;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Locale;

/**
 * 极简多语言：界面文案按中文原文查字典（assets/i18n/ui.json），查不到就回退中文。
 * 语言取值：system / zh-Hans / zh-Hant / en / ru / ja，默认 zh-Hans。
 */
public class L {

    private static JSONObject dict;
    private static String lang = "zh-Hans";

    public static void init(Context ctx) {
        if (dict == null) {
            try {
                InputStream is = ctx.getAssets().open("i18n/ui.json");
                BufferedReader br = new BufferedReader(new InputStreamReader(is, "UTF-8"));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) sb.append(line);
                br.close();
                dict = new JSONObject(sb.toString());
            } catch (Exception e) {
                dict = new JSONObject();
            }
        }
        SharedPreferences sp = ctx.getSharedPreferences("helper", Context.MODE_PRIVATE);
        String v = sp.getString("lang", "zh-Hans");
        lang = "system".equals(v) ? systemLang() : v;
    }

    public static String current() {
        return lang;
    }

    public static String setting(Context ctx) {
        return ctx.getSharedPreferences("helper", Context.MODE_PRIVATE).getString("lang", "zh-Hans");
    }

    public static String systemLang() {
        Locale l = Locale.getDefault();
        String code = l.getLanguage();
        if ("ru".equals(code)) return "ru";
        if ("ja".equals(code)) return "ja";
        if ("zh".equals(code)) {
            String c = l.getCountry();
            if ("TW".equals(c) || "HK".equals(c) || "MO".equals(c)) return "zh-Hant";
            if (Locales.isHantScript()) return "zh-Hant";
            return "zh-Hans";
        }
        return "en";
    }

    static class Locales {
        static boolean isHantScript() {
            try {
                return false;
            } catch (Exception e) {
                return false;
            }
        }
    }

    public static String label(String setting) {
        switch (setting) {
            case "system": return "跟随系统语言";
            case "zh-Hant": return "繁體中文";
            case "en": return "English";
            case "ru": return "Русский";
            case "ja": return "日本語";
            default: return "简体中文";
        }
    }

    public static String tr(String s) {
        if (s == null) return "";
        if ("zh-Hans".equals(lang) || dict == null) return s;
        JSONObject o = dict.optJSONObject(lang);
        if (o == null) return s;
        return o.optString(s, s);
    }
}
