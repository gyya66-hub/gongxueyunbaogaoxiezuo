package com.lc.reporthelper;

import android.content.Context;
import android.content.res.AssetManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * 报告生成引擎：读取 assets/content.json，按用户选择拼装周报 / 月报正文。
 */
public class ReportEngine {

    public static class Config {
        public String unit = "实习单位";
        public String post = "辅助岗位";
        public String name = "";
        public boolean monthly = false;
        public int index = 1;
        public final List<String> itemIds = new ArrayList<>();
    }

    private static JSONObject root;
    private static String rootLang = "";

    private static JSONObject root(Context ctx) throws Exception {
        String lg = L.current();
        if (root == null || !lg.equals(rootLang)) {
            String file;
            if ("zh-Hant".equals(lg)) file = "content_zh-Hant.json";
            else if ("en".equals(lg)) file = "content_en.json";
            else if ("ru".equals(lg)) file = "content_ru.json";
            else if ("ja".equals(lg)) file = "content_ja.json";
            else file = "content.json";
            AssetManager am = ctx.getAssets();
            InputStream is = am.open(file);
            BufferedReader br = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            br.close();
            root = new JSONObject(sb.toString());
            rootLang = lg;
        }
        return root;
    }

    public static class Item {
        public String id;
        public String name;
        public JSONArray week;
        public JSONArray month;
    }

    public static List<Item> items(Context ctx) throws Exception {
        List<Item> out = new ArrayList<>();
        JSONArray arr = root(ctx).getJSONArray("items");
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.getJSONObject(i);
            Item it = new Item();
            it.id = o.getString("id");
            it.name = o.getString("name");
            it.week = o.getJSONArray("week");
            it.month = o.getJSONArray("month");
            out.add(it);
        }
        return out;
    }

    private static String pick(JSONArray arr, Random r, int avoid) {
        if (arr == null || arr.length() == 0) return "";
        int idx = r.nextInt(arr.length());
        if (arr.length() > 1 && idx == avoid) idx = (idx + 1) % arr.length();
        try {
            return arr.getString(idx);
        } catch (Exception e) {
            return "";
        }
    }

    private static String fill(String s, Config c) {
        return s.replace("{unit}", c.unit)
                .replace("{post}", c.post)
                .replace("{n}", String.valueOf(c.index))
                .replace("{name}", c.name)
                .replace("{period}", c.monthly ? "月" : "周");
    }

    public static String generate(Context ctx, Config c) throws Exception {
        JSONObject r = root(ctx);
        Random rnd = new Random(System.nanoTime());
        StringBuilder sb = new StringBuilder();

        JSONObject h = r.optJSONObject("headers");
        if (h == null) h = new JSONObject();
        String title = fill(h.optString(c.monthly ? "titleMonth" : "titleWeek",
                c.monthly ? "第{n}个月实习月报" : "第{n}周实习周报"), c);
        if (c.name != null && c.name.trim().length() > 0) title += "（" + c.name.trim() + "）";
        sb.append(title).append("\n");
        sb.append(fill(h.optString("metaFmt", "实习单位：{unit}    岗位：{post}"), c)).append("\n\n");

        // 开头
        String opener = fill(pick(r.getJSONArray(c.monthly ? "monthOpeners" : "weekOpeners"), rnd, -1), c);
        sb.append(opener).append("\n\n");

        // 工作内容
        JSONArray allItems = r.getJSONArray("items");
        List<Item> chosen = new ArrayList<>();
        for (Item it : items(ctx)) {
            if (c.itemIds.contains(it.id)) chosen.add(it);
        }
        if (chosen.isEmpty()) {
            for (Item it : items(ctx)) chosen.add(it);
            if (chosen.size() > 3) chosen = chosen.subList(0, 3);
        }

        if (c.monthly) {
            sb.append(h.optString("basicMonth", "一、实习基本情况")).append("\n");
            sb.append(fill(h.optString("basicText",
                    "本月实习单位为{unit}，实习岗位为{post}，实习时间为第{n}个月。本月按车间安排正常出勤，遵守车间作息和安全规定，主要参与车间观摩学习和辅助岗位工作，整体实习情况稳定。"), c))
                    .append("\n\n");

            sb.append(h.optString("workMonth", "二、本月主要工作内容")).append("\n");
            for (int i = 0; i < chosen.size(); i++) {
                Item it = chosen.get(i);
                sb.append(i + 1).append(". ").append(it.name).append("：")
                        .append(fill(pick(it.month, rnd, -1), c)).append("\n");
            }
            sb.append("\n");

            sb.append(h.optString("gainsMonth", "三、学习与收获")).append("\n");
            JSONArray gains = r.getJSONArray("gains");
            int g1 = rnd.nextInt(gains.length());
            sb.append(fill(gains.getString(g1), c)).append("\n");
            int g2 = (g1 + 1 + rnd.nextInt(gains.length() - 1)) % gains.length();
            if (gains.length() > 1) sb.append(fill(gains.getString(g2), c)).append("\n");
            sb.append("\n");

            sb.append(h.optString("issuesMonth", "四、存在的不足与改进方向")).append("\n");
            sb.append(fill(pick(r.getJSONArray("issues"), rnd, -1), c)).append("\n");
            sb.append(h.optString("improveText", "针对以上不足，我会在后续实习中加强练习，多向师傅请教，做到操作前先确认要求、作业中按标准执行、完成后及时复核，把细节做扎实。")).append("\n\n");

            sb.append(h.optString("planMonth", "五、下月实习计划")).append("\n");
            sb.append(fill(pick(r.getJSONArray("monthPlans"), rnd, -1), c)).append("\n\n");

            sb.append(h.optString("summaryMonth", "六、实习总结")).append("\n");
            sb.append(fill(pick(r.getJSONArray("monthSummary"), rnd, -1), c)).append("\n\n");
        } else {
            sb.append(h.optString("workWeek", "一、本周主要工作内容")).append("\n");
            for (int i = 0; i < chosen.size(); i++) {
                Item it = chosen.get(i);
                sb.append(i + 1).append(". ").append(it.name).append("：")
                        .append(fill(pick(it.week, rnd, -1), c)).append("\n");
            }
            sb.append("\n");

            sb.append(h.optString("gainsWeek", "二、学习与收获")).append("\n");
            sb.append(fill(pick(r.getJSONArray("gains"), rnd, -1), c)).append("\n\n");

            sb.append(h.optString("issuesWeek", "三、存在的不足")).append("\n");
            sb.append(fill(pick(r.getJSONArray("issues"), rnd, -1), c)).append("\n\n");

            sb.append(h.optString("planWeek", "四、下周计划")).append("\n");
            sb.append(fill(pick(r.getJSONArray("weekPlans"), rnd, -1), c)).append("\n\n");
        }

        sb.append(fill(pick(r.getJSONArray("closings"), rnd, -1), c));
        return cleanup(sb.toString());
    }

    /** 去掉“岗位”重复、多余空格等小瑕疵 */
    private static String cleanup(String s) {
        return s.replace("岗岗位", "岗位")
                .replace("岗位岗位", "岗位")
                .replace("单位单位", "单位")
                .replace("，，", "，")
                .replace("。。", "。");
    }

    public static int charCount(String s) {
        int n = 0;
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch == ' ' || ch == '\n' || ch == '\r' || ch == '\t') continue;
            n++;
        }
        return n;
    }
}
