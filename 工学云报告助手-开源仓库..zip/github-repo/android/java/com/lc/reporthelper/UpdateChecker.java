package com.lc.reporthelper;

import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/** 版本信息与升级：远程 update.json 检查 + 系统下载器安装 */
public class UpdateChecker {

    public static final String VERSION_NAME = "2.5";
    public static final int VERSION_CODE = 17;

    public interface Callback {
        void onResult(boolean ok, String message, JSONObject info);
    }

    /**
     * update.json 格式：
     * { "versionCode": 3, "versionName": "1.2", "url": "https://.../app.apk",
     *   "size": "6.2MB", "changelog": "1. 新UI\n2. 修复若干问题", "force": false }
     */
    public static void check(final String url, final Callback cb) {
        final Handler h = new Handler(Looper.getMainLooper());
        new Thread(() -> {
            String msg;
            boolean ok = false;
            JSONObject info = null;
            try {
                HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
                conn.setConnectTimeout(8000);
                conn.setReadTimeout(8000);
                conn.setRequestProperty("User-Agent", "GongXueYunReport/" + VERSION_NAME);
                BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) sb.append(line);
                br.close();
                info = new JSONObject(sb.toString());
                int code = info.optInt("versionCode", 0);
                ok = true;
                msg = code > VERSION_CODE
                        ? "发现新版本 " + info.optString("versionName", "")
                        : "当前已是最新版本";
            } catch (Exception e) {
                msg = "检查失败：" + e.getClass().getSimpleName() + "（地址不通或格式不对）";
            }
            final String fm = msg;
            final boolean fok = ok;
            final JSONObject fi = info;
            h.post(() -> cb.onResult(fok, fm, fi));
        }).start();
    }

    public static void downloadAndInstall(final Context ctx, final String apkUrl, String versionName) {
        try {
            DownloadManager dm = (DownloadManager) ctx.getSystemService(Context.DOWNLOAD_SERVICE);
            if (dm == null) {
                Toast.makeText(ctx, "系统下载器不可用，请浏览器打开链接下载", Toast.LENGTH_SHORT).show();
                return;
            }
            String fileName = "GongXueYunReport-" + (versionName == null ? "new" : versionName) + ".apk";
            DownloadManager.Request req = new DownloadManager.Request(Uri.parse(apkUrl))
                    .setTitle("工学云报告助手 新版本")
                    .setDescription("正在下载安装包…")
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
                    .setAllowedOverMetered(true)
                    .setAllowedOverRoaming(true);
            final long id = dm.enqueue(req);
            Toast.makeText(ctx, "开始下载，下载完成后会弹出安装", Toast.LENGTH_SHORT).show();

            final BroadcastReceiver receiver = new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, Intent intent) {
                    if (id != intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1)) return;
                    try {
                        context.unregisterReceiver(this);
                    } catch (Exception ignored) {
                    }
                    try {
                        Uri uri = dm.getUriForDownloadedFile(id);
                        Intent i = new Intent(Intent.ACTION_VIEW)
                                .setDataAndType(uri, "application/vnd.android.package-archive")
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        context.startActivity(i);
                    } catch (Exception e) {
                        Toast.makeText(context, "请到「下载」目录找到 apk 手动安装", Toast.LENGTH_LONG).show();
                    }
                }
            };
            ctx.registerReceiver(receiver, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));
        } catch (Exception e) {
            Toast.makeText(ctx, "下载失败：" + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    /** 本地安装包升级：直接调起系统安装器 */
    public static Intent installIntent(Uri apkUri) {
        return new Intent(Intent.ACTION_VIEW)
                .setDataAndType(apkUri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_GRANT_READ_URI_PERMISSION);
    }

    public static SharedPreferences sp(Context c) {
        return c.getSharedPreferences("update", Context.MODE_PRIVATE);
    }
}
