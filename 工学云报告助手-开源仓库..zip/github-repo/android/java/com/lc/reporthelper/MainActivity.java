package com.lc.reporthelper;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.text.method.ScrollingMovementMethod;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    private static final String SP = "helper";
    private static final int REQ_PICK_APK = 2001;

    private SharedPreferences sp;
    private boolean wideMode;
    private LinearLayout leftCol, rightCol;
    private LinearLayout container;
    private ScrollView scroll;

    private TextView segWeek, segMonth;
    private TextView tvIndexValue, tvCount;
    private TextView tvResult, tvStat;
    private LinearLayout resultCard;
    private TextView btnGenerate;
    private final List<TextView> chipViews = new ArrayList<>();
    private final List<ReportEngine.Item> items = new ArrayList<>();
    private String lastText = "";

    /** 主题：system 跟随系统；light / dark 强制覆盖 */
    private void applyThemeMode() {
        String mode = sp.getString("theme", "system");
        if ("system".equals(mode)) return;
        try {
            android.content.res.Configuration cfg =
                    new android.content.res.Configuration(getResources().getConfiguration());
            int night = "dark".equals(mode)
                    ? android.content.res.Configuration.UI_MODE_NIGHT_YES
                    : android.content.res.Configuration.UI_MODE_NIGHT_NO;
            cfg.uiMode = (cfg.uiMode & ~android.content.res.Configuration.UI_MODE_NIGHT_MASK) | night;
            applyOverrideConfiguration(cfg);
        } catch (Exception ignored) {
        }
    }

    private String themeLabel() {
        String m = sp.getString("theme", "system");
        return "dark".equals(m) ? "深色" : ("light".equals(m) ? "浅色" : "跟随系统");
    }

    private void pickLanguage(TextView tv) {
        final String[] values = {"system", "zh-Hans", "zh-Hant", "en", "ru", "ja", "ko"};
        String[] labels = {"跟随系统语言", "简体中文", "繁体中文", "英语", "俄语", "日语", "韩语"};
        int checked = 0;
        String cur = L.setting(this);
        for (int i = 0; i < values.length; i++) if (values[i].equals(cur)) checked = i;
        new AlertDialog.Builder(this)
                .setTitle(L.tr("语言"))
                .setSingleChoiceItems(labels, checked, (d, which) -> {
                    sp.edit().putString("lang", values[which]).apply();
                    d.dismiss();
                    recreate();
                })
                .setNegativeButton(L.tr("取消"), null)
                .show();
    }

    private void pickTheme(final TextView tv) {
        String[] items = {"跟随系统", "浅色模式", "深色模式"};
        String cur = sp.getString("theme", "system");
        int idx = "dark".equals(cur) ? 2 : ("light".equals(cur) ? 1 : 0);
        new AlertDialog.Builder(this)
                .setTitle("外观主题")
                .setSingleChoiceItems(items, idx, (d, which) -> {
                    String mode = which == 0 ? "system" : (which == 1 ? "light" : "dark");
                    sp.edit().putString("theme", mode).apply();
                    d.dismiss();
                    recreate();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences(SP, MODE_PRIVATE);
        L.init(this);
        applyThemeMode();
        setContentView(R.layout.activity_main);
        container = findViewById(R.id.container);
        scroll = findViewById(R.id.scroll);
        try {
            items.addAll(ReportEngine.items(this));
        } catch (Exception e) {
            Toast.makeText(this, "内容库读取失败", Toast.LENGTH_LONG).show();
        }
        buildUi();
    }

    /* 复制完成后直接跳转工学云（固定行为，无开关） */
    private void openAfterCopyIfNeeded() {
        openGongxueyun();
    }

    /* ---------------- 基础样式 ---------------- */

    private int c(int resId) {
        return getResources().getColor(resId);
    }

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                getResources().getDisplayMetrics());
    }

    private TextView text(String s, float size, int color, boolean bold) {
        TextView tv = new TextView(this);
        tv.setText(L.tr(s));
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, size);
        tv.setTextColor(color);
        if (bold) tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setIncludeFontPadding(false);
        return tv;
    }

    private LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }

    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackgroundResource(R.drawable.card);
        l.setPadding(dp(16), dp(16), dp(16), dp(16));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(14);
        l.setLayoutParams(p);
        return l;
    }

    private LinearLayout headRow(String title, String right) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(2), 0, dp(2), dp(12));

        View dot = new View(this);
        dot.setBackgroundResource(R.drawable.dot);
        row.addView(dot, lp(dp(3), dp(3)));

        TextView t = text("  " + title, 12.5f, c(R.color.text_secondary), true);
        t.setLetterSpacing(0.08f);
        row.addView(t);

        if (right != null) {
            TextView r = text(right, 11.5f, c(R.color.text_tertiary), false);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            r.setGravity(Gravity.END);
            r.setLayoutParams(p);
            row.addView(r);
        }
        return row;
    }

    private TextView label(String s) {
        TextView t = text(s, 12f, c(R.color.text_secondary), false);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(10);
        p.bottomMargin = dp(6);
        t.setLayoutParams(p);
        return t;
    }

    private EditText input(final String key, String hint, String def) {
        EditText et = new EditText(this);
        et.setText(sp.getString(key, def));
        et.setHint(hint);
        et.setSingleLine(true);
        et.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f);
        et.setTextColor(c(R.color.text_primary));
        et.setHintTextColor(c(R.color.text_hint));
        et.setBackgroundResource(R.drawable.input);
        et.setPadding(dp(14), dp(11), dp(14), dp(11));
        et.setInputType(InputType.TYPE_CLASS_TEXT);
        et.setImeOptions(EditorInfo.IME_ACTION_DONE);
        et.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(Editable s) {
                sp.edit().putString(key, s.toString().trim()).apply();
            }

            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            public void onTextChanged(CharSequence s, int a, int b, int c) {
            }
        });
        return et;
    }

    private LinearLayout clickRow(String title, TextView value, View.OnClickListener l) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackgroundResource(R.drawable.row_flat);
        row.setFocusable(true);
        row.setClickable(true);
        row.setPadding(dp(10), dp(13), dp(10), dp(13));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(6);
        row.setLayoutParams(p);

        TextView t = text(title, 14.5f, c(R.color.text_primary), false);
        t.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(t);

        value.setGravity(Gravity.END);
        value.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        value.setTextColor(c(R.color.text_secondary));
        row.addView(value);

        row.setOnClickListener(l);
        return row;
    }

    /* ---------------- 界面 ---------------- */

    private void buildUi() {
        container.removeAllViews();
        wideMode = getResources().getConfiguration().smallestScreenWidthDp >= 600;
        if (wideMode) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setLayoutParams(new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            leftCol = new LinearLayout(this);
            leftCol.setOrientation(LinearLayout.VERTICAL);
            leftCol.setLayoutParams(new LinearLayout.LayoutParams(dp(360), ViewGroup.LayoutParams.WRAP_CONTENT));
            rightCol = new LinearLayout(this);
            rightCol.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            rp.leftMargin = dp(14);
            rightCol.setLayoutParams(rp);
            row.addView(leftCol);
            row.addView(rightCol);
            container.addView(row);
        } else {
            leftCol = container;
            rightCol = container;
        }
        header();
        settingsCard();
        itemsCard();
        generateButton();
        resultCard = resultUI();
        targetRight().addView(resultCard);
        moreCard();
        footer();
    }

    private LinearLayout targetLeft() { return wideMode && leftCol != null ? leftCol : container; }

    private LinearLayout targetRight() { return wideMode && rightCol != null ? rightCol : container; }

    private void header() {
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(dp(4), dp(14), dp(4), dp(4));

        ImageView icon = new ImageView(this);
        icon.setImageResource(R.mipmap.ic_launcher);
        head.addView(icon, lp(dp(44), dp(44)));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        cp.leftMargin = dp(12);
        col.setLayoutParams(cp);
        col.addView(text("工学云报告助手", 19f, c(R.color.text_primary), true));
        TextView sub = text("离线生成 · 一键复制 · 手机电脑通用", 11.5f, c(R.color.text_secondary), false);
        sub.setPadding(0, dp(4), 0, 0);
        col.addView(sub);
        head.addView(col);

        TextView ver = text("v" + UpdateChecker.VERSION_NAME, 11f, c(R.color.accent), true);
        ver.setBackgroundResource(R.drawable.badge);
        ver.setPadding(dp(9), dp(5), dp(9), dp(5));
        head.addView(ver);

        container.addView(head);
    }

    private void settingsCard() {
        LinearLayout c = card();
        c.addView(headRow("报告设置", null));

        LinearLayout segWrap = new LinearLayout(this);
        segWrap.setOrientation(LinearLayout.HORIZONTAL);
        segWrap.setBackgroundResource(R.drawable.seg_container);
        segWrap.setPadding(dp(4), dp(4), dp(4), dp(4));

        segWeek = text("周报", 14f, c(R.color.seg_text_on), true);
        segMonth = text("月报", 14f, c(R.color.seg_text_off), false);
        for (TextView t : new TextView[]{segWeek, segMonth}) {
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, dp(9), 0, dp(9));
            t.setFocusable(true);
            t.setClickable(true);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            t.setLayoutParams(p);
            segWrap.addView(t);
        }
        segWeek.setOnClickListener(v -> setMonthly(false));
        segMonth.setOnClickListener(v -> setMonthly(true));
        c.addView(segWrap);
        applySeg();

        c.addView(label("期数"));
        tvIndexValue = text(indexLabel(), 14.5f, c(R.color.text_primary), false);
        tvIndexValue.setGravity(Gravity.CENTER_VERTICAL);
        tvIndexValue.setBackgroundResource(R.drawable.input);
        tvIndexValue.setPadding(dp(14), dp(11), dp(14), dp(11));
        tvIndexValue.setFocusable(true);
        tvIndexValue.setClickable(true);
        tvIndexValue.setOnClickListener(v -> pickIndex());
        c.addView(tvIndexValue);

        c.addView(label("实习单位"));
        c.addView(input("unit", "例如：合肥中创新航科技有限公司", "合肥中创新航科技有限公司"));

        c.addView(label("实习岗位"));
        c.addView(input("post", "例如：汽车装配辅助岗", "汽车制造辅助岗"));


        targetLeft().addView(c);
    }

    private String indexLabel() {
        boolean m = sp.getBoolean("monthly", false);
        int i = sp.getInt("index", 1);
        return m ? ("第 " + i + " 个月") : ("第 " + i + " 周");
    }

    private void setMonthly(boolean m) {
        sp.edit().putBoolean("monthly", m).putInt("index", 1).apply();
        applySeg();
        if (tvIndexValue != null) tvIndexValue.setText(indexLabel());
        if (btnGenerate != null) btnGenerate.setText(m ? "生成月报并复制" : "生成周报并复制");
    }

    private void applySeg() {
        boolean m = sp.getBoolean("monthly", false);
        segWeek.setBackgroundResource(m ? R.drawable.seg_off : R.drawable.seg_on);
        segMonth.setBackgroundResource(m ? R.drawable.seg_on : R.drawable.seg_off);
        segWeek.setTextColor(m ? c(R.color.seg_text_off) : c(R.color.seg_text_on));
        segMonth.setTextColor(m ? c(R.color.seg_text_on) : c(R.color.seg_text_off));
        segWeek.setTypeface(Typeface.DEFAULT, m ? Typeface.NORMAL : Typeface.BOLD);
        segMonth.setTypeface(Typeface.DEFAULT, m ? Typeface.BOLD : Typeface.NORMAL);
    }

    private void itemsCard() {
        LinearLayout c = card();
        tvCount = text("已选 0 项", 11.5f, c(R.color.text_tertiary), false);
        LinearLayout row = headRow("工作内容", null);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        tvCount.setLayoutParams(tp);
        tvCount.setGravity(Gravity.END);
        row.addView(tvCount);
        c.addView(row);

        FlowLayout flow = new FlowLayout(this);
        flow.setLayoutParams(lp(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        chipViews.clear();
        for (ReportEngine.Item it : items) {
            TextView chip = text(it.name, 13f, c(R.color.chip_text), false);
            chip.setBackgroundResource(R.drawable.chip_off);
            chip.setPadding(dp(13), dp(9), dp(13), dp(9));
            chip.setFocusable(true);
            chip.setClickable(true);
            chip.setTag(it.id);
            chip.setOnClickListener(v -> {
                String cur = sp.getString("items", "");
                String[] arr = cur.split(",");
                List<String> list = new ArrayList<>();
                for (String s : arr) if (s.length() > 0) list.add(s);
                String id = (String) v.getTag();
                if (list.contains(id)) {
                    list.remove(id);
                } else {
                    if (list.size() >= 8) {
                        toast("最多勾选 8 项，太多了正文会变成罗列");
                        return;
                    }
                    list.add(id);
                }
                StringBuilder sb = new StringBuilder();
                for (String s : list) sb.append(s).append(",");
                sp.edit().putString("items", sb.toString()).apply();
                refreshChips();
            });
            chipViews.add(chip);
            flow.addView(chip);
        }
        c.addView(flow);

        TextView hint = text("建议勾选本周实际做过的 3-5 项，最多 8 项；每次生成措辞随机组合。",
                11.5f, c(R.color.text_tertiary), false);
        hint.setLineSpacing(dp(3), 1.15f);
        hint.setPadding(dp(2), dp(12), dp(2), 0);
        c.addView(hint);

        refreshChips();
        targetLeft().addView(c);
    }

    private void refreshChips() {
        String[] sel = sp.getString("items", "").split(",");
        List<String> list = new ArrayList<>();
        for (String s : sel) if (s.length() > 0) list.add(s);
        int n = 0;
        for (TextView chip : chipViews) {
            boolean on = list.contains((String) chip.getTag());
            chip.setBackgroundResource(on ? R.drawable.chip_on : R.drawable.chip_off);
            chip.setTextColor(on ? c(R.color.chip_text_on) : c(R.color.chip_text));
            if (on) n++;
        }
        if (tvCount != null) tvCount.setText("已选 " + n + " 项");
    }

    private void generateButton() {
        btnGenerate = text("生成周报并复制", 16f, c(R.color.btn_text), true);
        btnGenerate.setBackgroundResource(R.drawable.btn_primary);
        btnGenerate.setGravity(Gravity.CENTER);
        btnGenerate.setPadding(0, dp(16), 0, dp(16));
        btnGenerate.setFocusable(true);
        btnGenerate.setClickable(true);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(18);
        btnGenerate.setLayoutParams(p);
        btnGenerate.setText(sp.getBoolean("monthly", false) ? "生成月报并复制" : "生成周报并复制");
        btnGenerate.setOnClickListener(v -> generate(true));
        targetLeft().addView(btnGenerate);
    }

    private LinearLayout resultUI() {
        LinearLayout c = card();
        c.setVisibility(View.GONE);
        c.addView(headRow("生成结果", null));

        tvStat = text("", 11.5f, c(R.color.text_tertiary), false);
        tvStat.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        tvStat.setPadding(dp(2), 0, dp(2), dp(10));
        c.addView(tvStat);

        tvResult = text("", 14.5f, c(R.color.text_primary), false);
        tvResult.setLineSpacing(dp(6), 1.2f);
        tvResult.setBackgroundResource(R.drawable.card_inner);
        tvResult.setPadding(dp(14), dp(14), dp(14), dp(14));
        tvResult.setTextIsSelectable(true);
        tvResult.setOnClickListener(v -> editText());
        tvResult.setMovementMethod(new ScrollingMovementMethod());
        c.addView(tvResult);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        ap.topMargin = dp(12);
        actions.setLayoutParams(ap);

        String[] names = {"复制全文", "分享", "打开工学云"};
        for (int i = 0; i < names.length; i++) {
            TextView b = text(names[i], 13f, c(R.color.text_primary), false);
            b.setBackgroundResource(R.drawable.btn_ghost);
            b.setGravity(Gravity.CENTER);
            b.setPadding(0, dp(11), 0, dp(11));
            b.setFocusable(true);
            b.setClickable(true);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            p.rightMargin = i < names.length - 1 ? dp(8) : 0;
            b.setLayoutParams(p);
            if (i == 0) b.setOnClickListener(v -> {
                if (lastText.length() == 0) {
                    toast("先生成一份报告");
                    return;
                }
                copy(lastText);
                toast("已复制，去工学云长按粘贴即可");
            });
            if (i == 1) b.setOnClickListener(v -> {
                if (lastText.length() == 0) {
                    toast("先生成一份报告");
                    return;
                }
                share(lastText);
            });
            if (i == 2) b.setOnClickListener(v -> openGongxueyun());
            actions.addView(b);
        }
        c.addView(actions);
        return c;
    }

    private void moreCard() {
        LinearLayout c = card();
        c.addView(headRow("更多", null));

        TextView hv = text("", 13f, c(R.color.text_secondary), false);
        c.addView(clickRow("历史记录", hv, v -> showHistory()));

        TextView ev = text("导出 .txt", 13f, c(R.color.text_secondary), false);
        c.addView(clickRow("导出为文本文件", ev, v -> exportTxt()));

        TextView gv = text("点此跳转", 13f, c(R.color.text_secondary), false);
        c.addView(clickRow("打开工学云", gv, v -> openGongxueyun()));

        final TextView tvLang = text(L.label(L.setting(this)), 13f, c(R.color.text_secondary), false);
        c.addView(clickRow("语言", tvLang, v -> pickLanguage(tvLang)));

        final TextView tvTheme = text(themeLabel(), 13f, c(R.color.text_secondary), false);
        c.addView(clickRow("外观主题", tvTheme, v -> pickTheme(tvTheme)));

        TextView lv = text("选择 apk 覆盖安装", 13f, c(R.color.text_secondary), false);
        c.addView(clickRow("本地升级", lv, v -> pickLocalApk()));

        TextView av = text("v" + UpdateChecker.VERSION_NAME, 13f, c(R.color.text_secondary), false);
        c.addView(clickRow("关于本工具", av, v -> showAbout()));

        targetLeft().addView(c);
    }

    private void footer() {
        TextView note = text("数据只存在本机，不联网、不上传。"
                + "升级方式：把新版 apk 传到手机，点「本地升级」选安装包覆盖安装，记录会保留。"
                + "生成的文字请按自己真实的车间、岗位情况微调后再提交。", 11.5f, c(R.color.text_tertiary), false);
        note.setLineSpacing(dp(4), 1.2f);
        note.setPadding(dp(8), dp(18), dp(8), dp(28));
        container.addView(note);
    }

    /* ---------------- 动作 ---------------- */

    private void pickIndex() {
        boolean m = sp.getBoolean("monthly", false);
        int max = m ? 12 : 24;
        String[] arr = new String[max];
        for (int i = 0; i < max; i++) arr[i] = m ? ("第 " + (i + 1) + " 个月") : ("第 " + (i + 1) + " 周");
        new AlertDialog.Builder(this)
                .setTitle("选择期数")
                .setItems(arr, (d, which) -> {
                    sp.edit().putInt("index", which + 1).apply();
                    tvIndexValue.setText(indexLabel());
                    tvIndexValue.requestFocus();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private ReportEngine.Config config() {
        ReportEngine.Config c = new ReportEngine.Config();
        c.unit = sp.getString("unit", "实习单位");
        c.post = sp.getString("post", "辅助岗位");
        c.name = "";
        c.monthly = sp.getBoolean("monthly", false);
        c.index = sp.getInt("index", 1);
        String[] sel = sp.getString("items", "").split(",");
        for (String s : sel) if (s.length() > 0) c.itemIds.add(s);
        return c;
    }

    private void generate(boolean autoCopy) {
        try {
            ReportEngine.Config c = config();
            if (c.itemIds.isEmpty()) {
                toast("请先勾选至少一项工作内容");
                return;
            }
            if (c.unit.trim().isEmpty() || c.post.trim().isEmpty()) {
                toast("实习单位和岗位不要留空，学校可能会核对");
                return;
            }
            String text = ReportEngine.generate(this, c);
            lastText = text;
            resultCard.setVisibility(View.VISIBLE);
            tvResult.setText(text);
            int n = ReportEngine.charCount(text);
            int lo = c.monthly ? 1100 : 850, hi = c.monthly ? 1300 : 950;
            String lenTip = n < lo ? "　偏短，建议再生成一版" : (n > hi ? "　偏长，可手动删减" : "　字数合适");
            tvStat.setText(n + " 字" + lenTip + " · " + (c.monthly ? "月报" : "周报")
                    + " · 第" + c.index + (c.monthly ? "个月" : "周")
                    + " · " + new java.text.SimpleDateFormat("MM-dd HH:mm",
                    java.util.Locale.CHINA).format(new java.util.Date()));
            if (autoCopy) {
                copy(text);
                toast("已生成并复制，正在打开工学云…");
                openAfterCopyIfNeeded();
            } else {
                toast("已生成新的一版");
            }
            saveHistory(text, c);
            scroll.post(() -> scroll.smoothScrollTo(0, Math.max(0, resultCard.getTop() - dp(40))));
        } catch (Exception e) {
            toast("生成失败：" + e.getMessage());
        }
    }

    private void copy(String text) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("工学云报告", text));
    }

    /** 点正文可手动改几处再复制，方便填真实名字/细节 */
    private void editText() {
        if (lastText.isEmpty()) { toast("先生成一份报告"); return; }
        final EditText input = new EditText(this);
        input.setText(lastText);
        input.setTextSize(13);
        input.setGravity(Gravity.TOP);
        input.setMinLines(8);
        input.setPadding(dp(14), dp(12), dp(14), dp(12));
        new AlertDialog.Builder(this)
                .setTitle("编辑正文")
                .setView(input)
                .setPositiveButton("保存并复制", (d, w) -> {
                    lastText = input.getText().toString();
                    tvResult.setText(lastText);
                    tvStat.setText(ReportEngine.charCount(lastText) + " 字 · 已手动编辑");
                    copy(lastText);
                    toast("已保存并复制");
                })
                .setNegativeButton("取消", null)
                .show();
    }

    /** 导出为 txt，用系统文件选择器选保存位置，不需要存储权限 */
    private void exportTxt() {
        if (lastText.isEmpty()) { toast("先生成一份报告"); return; }
        try {
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("text/plain");
            String name = "工学云报告-" + new java.text.SimpleDateFormat("yyyyMMdd-HHmm",
                    java.util.Locale.CHINA).format(new java.util.Date()) + ".txt";
            i.putExtra(Intent.EXTRA_TITLE, name);
            startActivityForResult(i, 1001);
        } catch (Exception e) {
            toast("当前系统不支持导出，可先用分享");
        }
    }

    private void share(String text) {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TEXT, text);
        startActivity(Intent.createChooser(i, "分享到"));
    }

    private void openGongxueyun() {
        PackageManager pm = getPackageManager();
        String[] known = {"com.smilingmobile.practice"};
        for (String pkg : known) {
            Intent i = pm.getLaunchIntentForPackage(pkg);
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                try {
                    startActivity(i);
                    return;
                } catch (Exception ignored) {
                }
            }
        }
        Intent main = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> list = pm.queryIntentActivities(main, 0);
        for (ResolveInfo ri : list) {
            String label = ri.loadLabel(pm).toString();
            String pkg = ri.activityInfo.packageName;
            if (label.contains("工学云") || pkg.toLowerCase().contains("gongxueyun")
                    || pkg.toLowerCase().contains("smilingmobile")) {
                Intent i = pm.getLaunchIntentForPackage(pkg);
                if (i != null) {
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    try {
                        startActivity(i);
                        return;
                    } catch (Exception ignored) {
                    }
                }
            }
        }
        // 没装 App，就用浏览器打开工学云网页版
        try {
            Intent web = new Intent(Intent.ACTION_VIEW, Uri.parse("https://p3.gongxueyun.com/login"));
            web.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(web);
            toast("未安装工学云 App，已用浏览器打开网页版");
        } catch (Exception e) {
            toast("打开工学云失败，请手动打开");
        }
    }

    private void saveHistory(String text, ReportEngine.Config c) {
        try {
            JSONArray arr = new JSONArray(sp.getString("history", "[]"));
            JSONObject o = new JSONObject();
            o.put("t", System.currentTimeMillis());
            o.put("title", (c.monthly ? "第" + c.index + "个月月报" : "第" + c.index + "周周报"));
            o.put("text", text);
            JSONArray out = new JSONArray();
            out.put(o);
            for (int i = 0; i < arr.length() && i < 9; i++) out.put(arr.get(i));
            sp.edit().putString("history", out.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    private void showHistory() {
        try {
            JSONArray arr = new JSONArray(sp.getString("history", "[]"));
            if (arr.length() == 0) {
                toast("还没有生成记录");
                return;
            }
            final List<String> texts = new ArrayList<>();
            String[] labels = new String[arr.length()];
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                String time = new java.text.SimpleDateFormat("MM-dd HH:mm", java.util.Locale.CHINA)
                        .format(new java.util.Date(o.optLong("t")));
                labels[i] = time + "　" + o.optString("title");
                texts.add(o.optString("text"));
            }
            new AlertDialog.Builder(this)
                    .setTitle("历史记录（点击载入并复制）")
                    .setNeutralButton("清空全部", (d, w) -> {
                        sp.edit().putString("history", "[]").apply();
                        toast("已清空历史记录");
                    })
                    .setItems(labels, (d, which) -> {
                        lastText = texts.get(which);
                        resultCard.setVisibility(View.VISIBLE);
                        tvResult.setText(lastText);
                        tvStat.setText(ReportEngine.charCount(lastText) + " 字 · 历史记录");
                        copy(lastText);
                        toast("已载入并复制到剪贴板");
                    })
                    .setNegativeButton("关闭", null)
                    .show();
        } catch (Exception e) {
            toast("读取失败：" + e.getMessage());
        }
    }

    /* ---------------- 升级 ---------------- */


    /** 允许只填 "192.168.1.8:8080" / "http://ip/" 这类写法，自动补成完整 update.json 地址 */
    private String normalizeUpdateUrl(String raw) {
        String u = raw == null ? "" : raw.trim();
        if (u.length() == 0) return "";
        if (!u.startsWith("http://") && !u.startsWith("https://")) u = "http://" + u;
        u = u.replace(" ", "");
        while (u.endsWith("/")) u = u.substring(0, u.length() - 1);
        if (u.endsWith(".json")) return u;
        if (u.contains("update.json")) return u;
        return u + "/update.json";
    }


    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_PICK_APK && res == RESULT_OK && data != null && data.getData() != null) {
            installLocalApk(data.getData());
        }
        if (req == 1001 && res == RESULT_OK && data != null && data.getData() != null) {
            try {
                java.io.OutputStream os = getContentResolver().openOutputStream(data.getData());
                if (os != null) {
                    os.write(lastText.getBytes("UTF-8"));
                    os.close();
                    toast("已导出到所选位置");
                }
            } catch (Exception e) {
                toast("导出失败：" + e.getMessage());
            }
        }
    }

    private void pickLocalApk() {
        try {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.setType("application/vnd.android.package-archive");
            i.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(i, REQ_PICK_APK);
            toast("请选择新版 apk（手机里 Downloads 文件夹）");
        } catch (Exception e) {
            toast("没有找到文件管理器：" + e.getMessage());
        }
    }

    private void installLocalApk(Uri uri) {
        if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                        Uri.parse("package:" + getPackageName())));
                toast("请先允许本应用“安装未知应用”，再回来点本地升级");
            } catch (Exception e) {
                toast("请到系统设置里允许安装未知来源应用");
            }
            return;
        }
        try {
            startActivity(UpdateChecker.installIntent(uri));
            toast("已调起安装器，确认覆盖安装即可，原有记录会保留");
        } catch (Exception e) {
            toast("调起安装失败：" + e.getMessage());
        }
    }

    private void showAbout() {
        new AlertDialog.Builder(this)
                .setTitle("工学云报告助手 v" + UpdateChecker.VERSION_NAME)
                .setMessage("面向岗位实习（汽车制造方向）的周报 / 月报文字助手。\n\n"
                        + "· 完全离线生成，不上传数据\n"
                        + "· 生成后自动复制，粘贴到工学云提交\n"
                        + "· 支持手机、平板、电视遥控器操作\n"
                        + "· 升级：本地 apk 覆盖安装 / update.json 在线检查\n\n"
                        + "内容请结合真实工作微调后提交。")
                .setPositiveButton("知道了", null)
                .show();
    }

    private void toast(String s) {
        Toast.makeText(this, L.tr(s), Toast.LENGTH_SHORT).show();
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_UP) {
            int k = event.getKeyCode();
            if (k == KeyEvent.KEYCODE_DPAD_DOWN || k == KeyEvent.KEYCODE_DPAD_UP) {
                View f = getCurrentFocus();
                if (f != null && f != container) {
                    scroll.post(() -> {
                        int[] loc = new int[2];
                        f.getLocationInWindow(loc);
                        int h = getWindow().getDecorView().getHeight();
                        if (loc[1] < dp(60)) scroll.smoothScrollBy(0, -dp(80));
                        else if (loc[1] > h - dp(160)) scroll.smoothScrollBy(0, dp(80));
                    });
                }
            }
        }
        return super.dispatchKeyEvent(event);
    }
}
