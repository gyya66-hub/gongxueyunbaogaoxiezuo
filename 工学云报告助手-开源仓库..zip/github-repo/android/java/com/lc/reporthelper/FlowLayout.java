package com.lc.reporthelper;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;

/** 简易流式布局：标签自动换行，手机 / 电视都适用 */
public class FlowLayout extends ViewGroup {

    private int hGap;
    private int vGap;

    public FlowLayout(Context c) {
        this(c, null);
    }

    public FlowLayout(Context c, AttributeSet a) {
        super(c, a);
        float d = c.getResources().getDisplayMetrics().density;
        hGap = (int) (8 * d);
        vGap = (int) (10 * d);
    }

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        int width = MeasureSpec.getSize(widthSpec);
        if (MeasureSpec.getMode(widthSpec) == MeasureSpec.UNSPECIFIED) width = 1080;
        int lineWidth = 0, totalHeight = 0, lineHeight = 0, maxW = 0;
        for (int i = 0; i < getChildCount(); i++) {
            View child = getChildAt(i);
            if (child.getVisibility() == GONE) continue;
            measureChild(child, widthSpec, heightSpec);
            int cw = child.getMeasuredWidth();
            int ch = child.getMeasuredHeight();
            if (lineWidth + cw > width && lineWidth > 0) {
                totalHeight += lineHeight + vGap;
                lineHeight = 0;
                lineWidth = 0;
            }
            lineWidth += cw + (lineWidth > 0 ? hGap : 0);
            lineHeight = Math.max(lineHeight, ch);
            maxW = Math.max(maxW, lineWidth);
        }
        totalHeight += lineHeight;
        setMeasuredDimension(MeasureSpec.getMode(widthSpec) == MeasureSpec.EXACTLY ? width : maxW,
                totalHeight);
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        int width = r - l;
        int x = 0, y = 0, lineHeight = 0;
        for (int i = 0; i < getChildCount(); i++) {
            View child = getChildAt(i);
            if (child.getVisibility() == GONE) continue;
            int cw = child.getMeasuredWidth();
            int ch = child.getMeasuredHeight();
            if (x + cw > width && x > 0) {
                x = 0;
                y += lineHeight + vGap;
                lineHeight = 0;
            }
            child.layout(x, y, x + cw, y + ch);
            x += cw + hGap;
            lineHeight = Math.max(lineHeight, ch);
        }
    }
}
