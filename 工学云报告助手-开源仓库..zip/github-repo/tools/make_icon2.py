from PIL import Image, ImageDraw, ImageFilter

S=512
def base(size):
    img=Image.new("RGBA",(S,S),(0,0,0,0))
    # 渐变底
    grad=Image.new("RGB",(S,S))
    gd=ImageDraw.Draw(grad)
    for y in range(S):
        t=y/(S-1)
        gd.line([(0,y),(S,y)], fill=(int(143-60*t), int(192-60*t), int(255-8*t)))
    mask=Image.new("L",(S,S),0)
    ImageDraw.Draw(mask).rounded_rectangle([0,0,S,S],radius=112,fill=255)
    img.paste(grad,(0,0),mask)
    d=ImageDraw.Draw(img)
    # 左上高光
    hl=Image.new("RGBA",(S,S),(0,0,0,0))
    ImageDraw.Draw(hl).ellipse([-160,-200,320,200],fill=(255,255,255,80))
    hl=hl.filter(ImageFilter.GaussianBlur(60))
    img=Image.alpha_composite(img,hl)
    # 玻璃白卡
    card_layer=Image.new("RGBA",(S,S),(0,0,0,0))
    cd=ImageDraw.Draw(card_layer)
    cd.rounded_rectangle([132,96,380,392],radius=34,fill=(255,255,255,232),outline=(255,255,255,255),width=3)
    img=Image.alpha_composite(img,card_layer)
    d=ImageDraw.Draw(img)
    # 文档线条
    for i,w in enumerate([150,124,96]):
        y=185+i*48
        d.rounded_rectangle([176,y,176+w,y+16],radius=8,fill=(140,168,214,255))
    # 蓝色对勾圆标
    d.ellipse([300,300,404,404],fill=(47,107,255,255))
    d.line([(325,352),(348,376)],fill=(255,255,255,255),width=13)
    d.line([(348,376),(382,328)],fill=(255,255,255,255),width=13)
    return img.resize((size,size),Image.LANCZOS)

R='/home/user/Doubao/chats/38454082777637890/GongXueYunReport/app/src/main/res'
for folder,size in {"mipmap-mdpi":48,"mipmap-hdpi":72,"mipmap-xhdpi":96,"mipmap-xxhdpi":144,"mipmap-xxxhdpi":192}.items():
    base(size).save(f'{R}/{folder}/ic_launcher.png')

# TV banner
b=Image.new('RGB',(320,180),(238,242,255))
mask=Image.new('L',(320,180),0); ImageDraw.Draw(mask).rounded_rectangle([0,0,320,180],radius=22,fill=255)
bg=Image.new('RGB',(320,180))
bd=ImageDraw.Draw(bg)
for x in range(320):
    t=x/319
    bd.line([(x,0),(x,180)],fill=(int(226+20*t),int(233+5*t),int(255-15*t)))
b.paste(bg,(0,0),mask)
ic=base(112)
b.paste(ic,(28,34),ic)
bd2=ImageDraw.Draw(b)
# 装饰光斑
for pos,r,c in [((250,40),46,(47,107,255)),((292,140),34,(255,150,170)),((210,150),26,(150,255,220))]:
    over=Image.new('RGBA',(320,180),(0,0,0,0))
    ImageDraw.Draw(over).ellipse([pos[0]-r,pos[1]-r,pos[0]+r,pos[1]+r],fill=c+(70,))
    over=over.filter(ImageFilter.GaussianBlur(16))
    b=Image.alpha_composite(b.convert('RGBA'),over).convert('RGB')
b.save(f'{R}/drawable/banner.png')

# Windows 图标
base(256).save('/home/user/build/app.ico',sizes=[(256,256),(128,128),(64,64),(48,48),(32,32),(16,16)])
base(180).save('/home/user/build/icon_preview.png')
print('icon ok')
