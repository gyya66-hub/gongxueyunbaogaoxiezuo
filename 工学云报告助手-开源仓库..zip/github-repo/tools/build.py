# -*- coding: utf-8 -*-
import json, opencc, io, os
S2T = opencc.OpenCC('s2t')

ui = {
"工学云报告助手":{"en":"Gongxueyun Report Helper","ru":"Помощник отчётов Gongxueyun","ja":"工学雲レポート補助"},
"离线生成 · 一键复制 · 手机电脑通用":{"en":"Offline generation · one-tap copy · phone & desktop","ru":"Офлайн-генерация · копирование в один клик","ja":"オフライン生成・ワンタップコピー"},
"跟随系统":{"en":"System","ru":"Система","ja":"システム"},
"简体中文":{"en":"简体中文","ru":"简体中文","ja":"簡体字中国語"},
"繁體中文":{"en":"繁體中文","ru":"繁體中文","ja":"繁体字中国語"},
"English":{"en":"English","ru":"English","ja":"English"},
"Русский":{"en":"Русский","ru":"Русский","ja":"Русский"},
"日本語":{"en":"日本語","ru":"日本語","ja":"日本語"},
"语言":{"en":"Language","ru":"Язык","ja":"言語"},
"外观主题":{"en":"Theme","ru":"Тема","ja":"テーマ"},
"跟随系统主题":{"en":"Follow system","ru":"Как в системе","ja":"システムに従う"},
"浅色":{"en":"Light","ru":"Светлая","ja":"ライト"},
"深色":{"en":"Dark","ru":"Тёмная","ja":"ダーク"},
"报告设置":{"en":"Report settings","ru":"Настройки отчёта","ja":"レポート設定"},
"报告类型":{"en":"Report type","ru":"Тип отчёта","ja":"レポート種別"},
"周报":{"en":"Weekly","ru":"Недельный","ja":"週報"},
"月报":{"en":"Monthly","ru":"Месячный","ja":"月報"},
"期数":{"en":"Period","ru":"Период","ja":"期"},
"实习单位":{"en":"Company","ru":"Предприятие","ja":"実習先"},
"实习岗位":{"en":"Position","ru":"Должность","ja":"実習職種"},
"姓名（可留空）":{"en":"Name (optional)","ru":"Имя (необязательно)","ja":"氏名（任意）"},
"工作内容":{"en":"Work items","ru":"Виды работ","ja":"作業内容"},
"生成周报并复制":{"en":"Generate weekly & copy","ru":"Создать недельный и копировать","ja":"週報を生成してコピー"},
"生成月报并复制":{"en":"Generate monthly & copy","ru":"Создать месячный и копировать","ja":"月報を生成してコピー"},
"生成结果":{"en":"Result","ru":"Результат","ja":"生成結果"},
"复制全文":{"en":"Copy","ru":"Копировать","ja":"全文コピー"},
"分享":{"en":"Share","ru":"Поделиться","ja":"共有"},
"打开工学云":{"en":"Open Gongxueyun","ru":"Открыть Gongxueyun","ja":"工学雲を開く"},
"更多":{"en":"More","ru":"Ещё","ja":"その他"},
"报告设置更多":{"en":"More settings","ru":"Доп. настройки","ja":"その他の設定"},
"历史记录":{"en":"History","ru":"История","ja":"履歴"},
"检查更新":{"en":"Check update","ru":"Проверить обновления","ja":"アップデート確認"},
"本地升级":{"en":"Local upgrade","ru":"Локальное обновление","ja":"ローカル更新"},
"关于本工具":{"en":"About","ru":"О программе","ja":"このアプリについて"},
"保存":{"en":"Save","ru":"Сохранить","ja":"保存"},
"取消":{"en":"Cancel","ru":"Отмена","ja":"キャンセル"},
"关闭":{"en":"Close","ru":"Закрыть","ja":"閉じる"},
"先生成一份报告":{"en":"Generate a report first","ru":"Сначала создайте отчёт","ja":"先にレポートを生成してください"},
"已复制，去工学云长按粘贴即可":{"en":"Copied. Long-press to paste in Gongxueyun.","ru":"Скопировано. Вставьте в Gongxueyun долгим нажатием.","ja":"コピーしました。工学雲で長押しして貼り付けます。"},
"建议勾选本周实际做过的 3-5 项，文案会跟着变化；每次生成措辞随机组合。":{"en":"Pick 3-5 items you actually did; wording changes with your selection and is randomized each time.","ru":"Выберите 3–5 фактически выполненных пунктов: текст зависит от выбора и меняется при каждой генерации.","ja":"実際に行った3〜5項目を選んでください。選択に応じて文章が変わり、毎回表現も変わります。"},
"已载入并复制到剪贴板":{"en":"Loaded and copied","ru":"Загружено и скопировано","ja":"読み込んでコピーしました"},
"验证码":{"en":"Captcha","ru":"Код","ja":"コード"},
}

langs = ["zh-Hant","en","ru","ja"]
out = {}
for lg in langs:
    d = {}
    for k,v in ui.items():
        if lg == "zh-Hant":
            d[k] = S2T.convert(k)
        else:
            d[k] = v[lg]
    out[lg] = d
json.dump(out, open('/home/user/build/i18n/ui.json','w',encoding='utf-8'), ensure_ascii=False, indent=1)
print('ui keys', len(ui), 'langs', list(out.keys()))

# 报告正文繁体版
src='/home/user/Doubao/chats/38454082777637890/GongXueYunReport/app/src/main/assets/content.json'
data=json.load(open(src,encoding='utf-8'))
def conv(o):
    if isinstance(o,str): return S2T.convert(o)
    if isinstance(o,list): return [conv(x) for x in o]
    if isinstance(o,dict): return {k:(conv(v) if k!='id' else v) for k,v in o.items()}
    return o
hant=conv(data)
hant['lang']='zh-Hant'
json.dump(hant,open('/home/user/build/i18n/content_zh-Hant.json','w',encoding='utf-8'),ensure_ascii=False,indent=1)
print('hant ok', os.path.getsize('/home/user/build/i18n/content_zh-Hant.json'))
