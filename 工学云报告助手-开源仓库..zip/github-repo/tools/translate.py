#!/usr/bin/env python3
"""把 content.json 的文案段落用 MyMemory 翻成 en / ru / ja，带缓存与重试。"""
import json, os, re, sys, time, threading, urllib.parse, urllib.request
from concurrent.futures import ThreadPoolExecutor

SRC = '/home/user/Doubao/chats/38454082777637890/GongXueYunReport/app/src/main/assets/content.json'
CACHE = '/home/user/build/i18n/tcache.json'
PH = re.compile(r'\{[a-zA-Z]+\}')

LANGS = ['en', 'ru', 'ja']

def mask_ph(s):
    m = []
    def rep(mo):
        m.append(mo.group(0))
        return '\u27e6%d\u27e7' % (len(m) - 1)
    return PH.sub(rep, s), m

def unmask(s, m):
    for i, ph in enumerate(m):
        for variant in ('\u27e6%d\u27e7' % i, '[[%d]]' % i, '[%d]' % i, '%d' % i if False else '\u27e6%d\u27e7' % i):
            s = s.replace(variant, ph)
    return s

lock = threading.Lock()
cache = {}
if os.path.exists(CACHE):
    cache = json.load(open(CACHE, encoding='utf-8'))

def translate_one(text, tl):
    key = tl + '|' + text
    with lock:
        if key in cache:
            return cache[key]
    masked, m = mask_ph(text)
    q = urllib.parse.quote(masked)
    url = 'https://api.mymemory.translated.net/get?q=%s&langpair=zh-CN|%s' % (q, tl)
    for attempt in range(6):
        try:
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
            d = json.loads(urllib.request.urlopen(req, timeout=25).read())
            if str(d.get('responseStatus')) != '200':
                raise ValueError(d.get('responseDetails'))
            out = d['responseData']['translatedText']
            if not out or out.strip() == masked.strip():
                raise ValueError('empty')
            if '\u27e6' in out:
                out = re.sub(r'\u27e6\s*(\d+)\s*\u27e7', lambda mo: '\u27e6%s\u27e7' % mo.group(1), out)
            res = unmask(out, m)
            with lock:
                cache[key] = res
                if len(cache) % 20 == 0:
                    json.dump(cache, open(CACHE, 'w', encoding='utf-8'), ensure_ascii=False)
            return res
        except Exception as e:
            time.sleep(1.6 + attempt * 1.4)
    with lock:
        cache[key] = text
    return text

def collect(obj, out, path=''):
    if isinstance(obj, str):
        out.append((path, obj))
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            collect(v, out, path + '/%d' % i)
    elif isinstance(obj, dict):
        for k, v in obj.items():
            collect(v, out, path + '/' + k)

def setpath(obj, path, val):
    parts = [p for p in path.split('/') if p]
    cur = obj
    for p in parts[:-1]:
        cur = cur[int(p)] if isinstance(cur, list) else cur[p]
    last = parts[-1]
    if isinstance(cur, list):
        cur[int(last)] = val
    else:
        cur[last] = val

def main():
    src = json.load(open(SRC, encoding='utf-8'))
    strings = []
    collect(src, strings)
    strs = [s for _, s in strings if len(s.strip()) > 1]
    todo = [(tl, s) for tl in LANGS for s in strs]
    print('strings', len(strs), 'jobs', len(todo))
    done = [0]
    def work(job):
        tl, s = job
        r = translate_one(s, tl)
        with lock:
            done[0] += 1
            if done[0] % 15 == 0:
                print('[%d/%d]' % (done[0], len(todo)), flush=True)
                json.dump(cache, open(CACHE, 'w', encoding='utf-8'), ensure_ascii=False)
        return (tl, s, r)
    with ThreadPoolExecutor(max_workers=6) as ex:
        results = list(ex.map(work, todo))
    json.dump(cache, open(CACHE, 'w', encoding='utf-8'), ensure_ascii=False)
    for tl in LANGS:
        newobj = json.loads(json.dumps(src))
        mp = {s: r for (l, s, r) in results if l == tl}
        for path, s in strings:
            if len(s.strip()) > 1:
                setpath(newobj, path, mp.get(s, s))
        out = '/home/user/build/i18n/content_%s.json' % tl
        json.dump(newobj, open(out, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
        print('wrote', out, os.path.getsize(out))

if __name__ == '__main__':
    main()
