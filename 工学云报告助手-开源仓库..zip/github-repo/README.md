# 工学云报告助手 · GongXueYun Report Helper

面向**汽车制造类岗位实习**的周报 / 月报文字生成器。全程离线生成，不登录、不上传、不代提交，
生成后自动复制到剪贴板，你自己去工学云粘贴。

> 非官方工具，与工学云平台无关联。文案供参考，提交前请按真实工作经历核对修改。

## 直接使用（不想看代码）

| 端 | 说明 |
|---|---|
| 安卓 | 装 `apk` 即用，5.0 以上；平板自动双栏 |
| 电脑 | 单个 `exe`，Win7 / 10 / 11 都能跑 |
| 网页 | 一个 `html` 文件，双击就用，不需要服务器（限电脑访问） |
| iOS | SwiftUI 工程，需 Xcode 或 GitHub Actions 编译（Apple 签名限制） |
| 鸿蒙 | ArkTS 工程，需 DevEco Studio 编译 hap |

## 功能

- **六语言**：简体 / 繁体 / 英语 / 俄语 / 日语 / 韩语，界面和正文全部离线内置
- **双主题 + 三档**：跟随系统 / 浅色 / 深色，AI 插画底图两套
- **22 项工作内容**：观摩、装配、点检、质检、焊装、涂装、冲压、动力电池、物流、设备保养、质量追溯、MES、精益改善、技能培训等
- **实用辅助**：钩选上限 8 项、字数区间提示、单位/岗位空值拦截、正文可编辑、导出 txt、历史记录
- **完全离线**：不联网检查更新，升级用本地 apk 覆盖安装

## 目录

```
android/    安卓（Java + 手写 XML 布局，不依赖 Gradle）
desktop/    网页版与 Windows 封装（HTML 单文件 + C launcher）
ios/        iOS（SwiftUI，iOS 15+，iPhone/iPad 通用）
harmony/    鸿蒙（ArkTS，HarmonyOS NEXT 5.0）
tools/      内容库生成与机翻脚本、图标脚本
scripts/    一键构建脚本
docs/       更新说明、编译教程
```

## 构建

### 安卓
需要 JDK 17 + Android SDK（build-tools 33、platform android-33）：
```bash
export ANDROID_HOME=$HOME/Android/Sdk
bash scripts/build_apk.sh          # 产物 build/apk/app.apk
```
没有 Gradle 依赖，改完 Java 直接重编译，一次约 20 秒。

### 网页 / 电脑版
```bash
bash scripts/build_web.sh          # 生成 desktop/app.html，浏览器打开即用
bash scripts/build_exe.sh          # 需 mingw-w64，交叉编译出单文件 exe
```

### iOS
用 Xcode 打开 `ios/GongXueYunReport.xcodeproj`，选 Team 后 Run / Archive。
没有 Mac 的走 `.github/workflows/ios.yml`（macOS runner 编译 unsigned ipa，再用 Sideloadly 自签）。
iOS 安装包必须经 Apple 工具链签名，这是平台限制。

### 鸿蒙
DevEco Studio 5.0 打开 `harmony/GongXueYunReportHarmony`，勾自动签名，Run 装真机。

## 修改指南

想改文案、加语言、换主题？看 [CONTRIBUTING.md](CONTRIBUTING.md)，里面写了三件事：
1. 加 / 改工作内容（改 `content.json` 后跑生成与翻译脚本）
2. 加一门新语言（要动 6 个文件，清单在内）
3. 改界面与主题（CSS 变量 / 各端页面文件位置）

## 许可

MIT License，见 [LICENSE](LICENSE)。可自由使用、修改、再分发，保留版权声明即可。

## 免责

- 生成的文案供参考，请核对与实际实习经历一致，勿编造产量、工时等可核查数据
- 背景插画为 AI 生成素材，商用前请自行确认版权
- 使用本工具产生的任何后果由使用者自行承担
