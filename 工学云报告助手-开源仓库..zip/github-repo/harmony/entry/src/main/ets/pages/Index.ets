import { common, Want } from '@kit.AbilityKit';
import { pasteboard, BusinessError } from '@kit.BasicServicesKit';
import { mediaquery } from '@kit.ArkUI';
import { util } from '@kit.ArkTS';
import { ContentPack, ItemDef, Config, Engine } from '../model/Engine';

const LANGS: string[] = ['zh', 'zh-Hant', 'en', 'ru', 'ja', 'ko'];
const LANG_LABELS: string[] = ['简体中文', '繁體中文', 'English', 'Русский', '日本語', '한국어'];
const GXY_URL: string = 'https://p3.gongxueyun.com/login';

@Entry
@Component
struct Index {
  @State pack: ContentPack | null = null;
  @State lang: string = 'zh';
  @State themeMode: number = 0;
  @State sysDark: boolean = false;
  @State monthly: boolean = false;
  @State periodIndex: number = 1;
  @State unit: string = '某某汽车科技有限公司';
  @State post: string = '汽车制造辅助岗';
  @State selected: string[] = ['observe', 'assemble', 'inspect'];
  @State report: string = '';
  @State notice: string = '';
  @State wide: boolean = false;

  private ctx: common.UIAbilityContext = getContext(this) as common.UIAbilityContext;
  private darkMq: mediaquery.MediaQueryListener = mediaquery.matchMediaSync('(dark-mode: true)');
  private wideMq: mediaquery.MediaQueryListener = mediaquery.matchMediaSync('(width>=600vp)');

  aboutToAppear(): void {
    this.sysDark = this.darkMq.matches;
    this.darkMq.on('change', (r: mediaquery.MediaQueryResult) => {
      this.sysDark = r.matches;
    });
    this.wide = this.wideMq.matches;
    this.wideMq.on('change', (r: mediaquery.MediaQueryResult) => {
      this.wide = r.matches;
    });
    this.loadPack();
  }

  private async loadPack(): Promise<void> {
    try {
      let buf: Uint8Array = await this.ctx.resourceManager.getRawFileContent(Engine.fileOf(this.lang));
      let dec: util.TextDecoder = util.TextDecoder.create('utf-8');
      let text: string = dec.decodeToString(buf);
      this.pack = JSON.parse(text) as ContentPack;
    } catch (e) {
      this.notice = '内容库加载失败：' + String(e);
    }
  }

  private periodOptions(): SelectOption[] {
    let out: SelectOption[] = [];
    for (let n = 1; n <= 12; n++) {
      out.push({ value: this.monthly ? '第 ' + n + ' 个月' : '第 ' + n + ' 周' });
    }
    return out;
  }

  private isDark(): boolean {
    if (this.themeMode === 0) {
      return this.sysDark;
    }
    return this.themeMode === 2;
  }

  private textColor(): string {
    return this.isDark() ? '#E9EEF7' : '#1B2430';
  }

  private subColor(): string {
    return this.isDark() ? '#93A1B5' : '#66748A';
  }

  private cardBg(): string {
    return this.isDark() ? '#1C2431CC' : '#FFFFFFCC';
  }

  private fieldBg(): string {
    return this.isDark() ? '#FFFFFF14' : '#FFFFFFF2';
  }

  private toggleItem(id: string): void {
    let i: number = this.selected.indexOf(id);
    if (i >= 0) {
      this.selected.splice(i, 1);
    } else {
      if (this.selected.length >= 8) {
        this.notice = '最多勾选 8 项，太多了正文会变成罗列';
        return;
      }
      this.selected.push(id);
      this.notice = '';
    }
  }

  private wordTip(): string {
    let n: number = Engine.charCount(this.report);
    if (n === 0) {
      return '0 字';
    }
    let lo: number = this.monthly ? 1100 : 850;
    let hi: number = this.monthly ? 1300 : 950;
    let tip: string = n < lo ? '偏短，建议再生成一版' : (n > hi ? '偏长，可手动删减' : '字数合适');
    return n.toString() + ' 字 · ' + tip;
  }

  private doGenerate(): void {
    if (this.pack === null) {
      this.notice = '内容库还没加载好，稍等一下再试';
      return;
    }
    if (this.unit.trim().length === 0 || this.post.trim().length === 0) {
      this.notice = '实习单位和岗位不要留空，学校可能会核对';
      return;
    }
    let c: Config = new Config();
    c.unit = this.unit;
    c.post = this.post;
    c.name = '';
    c.monthly = this.monthly;
    c.index = this.periodIndex;
    c.itemIds = this.selected.slice(0);
    this.report = Engine.generate(this.pack as ContentPack, c);
    this.notice = '';
  }

  private async copy(): Promise<void> {
    if (this.report.length === 0) {
      this.notice = '先点「生成并复制」';
      return;
    }
    try {
      let data: pasteboard.PasteData =
        pasteboard.createData(pasteboard.MIMETYPE_TEXT_PLAIN, this.report);
      await pasteboard.getSystemPasteboard().setData(data);
      this.notice = '已复制，去工学云长按粘贴即可';
    } catch (e) {
      this.notice = '复制失败：' + String(e);
    }
  }

  private openGxy(): void {
    let want: Want = { action: 'ohos.want.action.viewData', uri: GXY_URL };
    this.ctx.startAbility(want).catch((e: BusinessError) => {
      this.notice = '打开工学云失败：' + e.message;
    });
  }

  private async generateAndCopy(): Promise<void> {
    this.doGenerate();
    await this.copy();
  }

  private async generateAndOpen(): Promise<void> {
    this.doGenerate();
    await this.copy();
    this.openGxy();
  }

  @Builder
  chip(label: string, on: boolean, action: () => void) {
    Text(label)
      .fontSize(13)
      .fontColor(on ? '#FFFFFF' : this.textColor())
      .padding({ left: 14, right: 14, top: 7, bottom: 7 })
      .backgroundColor(on ? '#2F6DF6' : this.fieldBg())
      .borderRadius(16)
      .margin({ right: 8, bottom: 8 })
      .onClick(action)
  }

  @Builder
  segButton(label: string, on: boolean, action: () => void) {
    Text(label)
      .fontSize(13)
      .fontColor(on ? '#FFFFFF' : this.textColor())
      .textAlign(TextAlign.Center)
      .layoutWeight(1)
      .padding({ top: 9, bottom: 9 })
      .backgroundColor(on ? '#2F6DF6' : this.fieldBg())
      .borderRadius(10)
      .onClick(action)
  }

  @Builder
  sectionTitle(t: string) {
    Row() {
      Text(t).fontSize(14).fontColor(this.subColor()).fontWeight(FontWeight.Medium)
      Blank()
    }.width('100%').margin({ bottom: 8 })
  }

  @Builder
  panel() {
    Scroll() {
      Column() {
        this.sectionTitle('报告类型')
        Row({ space: 8 }) {
          this.segButton('周报', !this.monthly, () => { this.monthly = false; })
          this.segButton('月报', this.monthly, () => { this.monthly = true; })
        }.width('100%').margin({ bottom: 14 })

        this.sectionTitle(this.monthly ? '第几个月' : '第几周')
        Select(this.periodOptions())
          .selected(this.periodIndex - 1)
          .value(this.monthly ? '第 ' + this.periodIndex + ' 个月' : '第 ' + this.periodIndex + ' 周')
          .fontColor(this.textColor())
          .backgroundColor(this.fieldBg())
          .width('100%')
          .onSelect((i: number) => { this.periodIndex = i + 1; })
          .margin({ bottom: 14 })

        this.sectionTitle('实习单位')
        TextInput({ text: this.unit, placeholder: '例如：某某汽车科技有限公司' })
          .fontColor(this.textColor())
          .backgroundColor(this.fieldBg())
          .width('100%')
          .margin({ bottom: 14 })
          .onChange((v: string) => { this.unit = v; })

        this.sectionTitle('实习岗位')
        TextInput({ text: this.post, placeholder: '例如：汽车制造辅助岗' })
          .fontColor(this.textColor())
          .backgroundColor(this.fieldBg())
          .width('100%')
          .margin({ bottom: 14 })
          .onChange((v: string) => { this.post = v; })

        Row() {
          Text('工作内容').fontSize(14).fontColor(this.subColor())
          Blank()
          Text('已选 ' + this.selected.length + ' 项').fontSize(12).fontColor(this.subColor())
        }.width('100%').margin({ bottom: 8 })

        Flex({ wrap: FlexWrap.Wrap }) {
          ForEach((this.pack?.items ?? []) as ItemDef[], (it: ItemDef) => {
            this.chip(it.name, this.selected.indexOf(it.id) >= 0, () => { this.toggleItem(it.id); })
          }, (it: ItemDef) => it.id)
        }.width('100%')
      }
      .padding(16)
      .width('100%')
    }
    .scrollBar(BarState.Off)
  }

  @Builder
  resultPanel() {
    Column() {
      Row({ space: 8 }) {
        this.segButton('生成并复制', false, () => { this.generateAndCopy(); })
        this.segButton('生成并打开工学云', false, () => { this.generateAndOpen(); })
      }.width('100%')

      Row() {
        Text('复制全文').fontSize(13).fontColor(this.textColor())
          .padding({ left: 12, right: 12, top: 7, bottom: 7 })
          .backgroundColor(this.fieldBg()).borderRadius(14)
          .onClick(() => { this.copy(); })
        Text('换一版').fontSize(13).fontColor(this.textColor())
          .padding({ left: 12, right: 12, top: 7, bottom: 7 })
          .backgroundColor(this.fieldBg()).borderRadius(14)
          .margin({ left: 8 })
          .onClick(() => { this.doGenerate(); })
        Blank()
        Text(this.wordTip()).fontSize(11).fontColor(this.subColor())
      }.width('100%').margin({ top: 10, bottom: 8 })

      if (this.notice.length > 0) {
        Text(this.notice).fontSize(11).fontColor('#FF9F43').margin({ bottom: 8 })
      }

      TextArea({ text: this.report, placeholder: '点「生成并复制」，正文会自动出现在这里并复制到剪贴板，直接去工学云粘贴提交即可。' })
        .fontSize(14)
        .fontColor(this.textColor())
        .backgroundColor(this.fieldBg())
        .borderRadius(14)
        .layoutWeight(1)
        .width('100%')
        .onChange((v: string) => { this.report = v; })
    }
    .layoutWeight(1)
    .height('100%')
  }

  @Builder
  topBar() {
    Row() {
      Column() {
        Text('工学云报告助手').fontSize(17).fontWeight(FontWeight.Bold).fontColor(this.textColor())
        Text('离线生成 · 一键复制 · 手机 / 电脑 / 网页同一套界面').fontSize(11).fontColor(this.subColor())
      }.alignItems(HorizontalAlign.Start)
      Blank()
      Text(this.themeMode === 0 ? '跟随系统' : (this.themeMode === 1 ? '浅色' : '深色'))
        .fontSize(12).fontColor('#2F6DF6')
        .padding({ left: 12, right: 12, top: 6, bottom: 6 })
        .backgroundColor(this.fieldBg()).borderRadius(12)
        .onClick(() => { this.themeMode = (this.themeMode + 1) % 3; })
    }
    .width('100%')
    .padding({ left: 16, right: 16, top: 10, bottom: 10 })
    .backgroundColor(this.cardBg())
  }

  build() {
    Stack({ alignContent: Alignment.TopStart }) {
      Image(this.isDark() ? $r('app.media.bg_dark_ai') : $r('app.media.bg_light_ai'))
        .width('100%').height('100%').objectFit(ImageFit.Cover)
      Column() {
        this.topBar()
        Flex({ wrap: FlexWrap.Wrap }) {
          ForEach(LANGS, (lg: string, i: number) => {
            this.chip(LANG_LABELS[i], this.lang === lg, async () => {
              this.lang = lg;
              await this.loadPack();
              this.notice = '';
            })
          }, (lg: string) => lg)
        }
        .width('100%')
        .padding({ left: 16, right: 16, top: 8, bottom: 2 })

        if (this.wide) {
          Row({ space: 12 }) {
            Column() { this.panel() }
              .width(360)
              .layoutWeight(0)
              .backgroundColor(this.cardBg())
              .borderRadius(20)
              .backdropBlur(18)
              .height('100%')
            Column() { this.resultPanel() }
              .layoutWeight(1)
              .backgroundColor(this.cardBg())
              .borderRadius(20)
              .backdropBlur(18)
              .height('100%')
              .padding(14)
          }
          .layoutWeight(1)
          .padding({ left: 16, right: 16, top: 8, bottom: 16 })
          .width('100%')
        } else {
          Column({ space: 10 }) {
            Column() { this.panel() }
              .backgroundColor(this.cardBg())
              .borderRadius(20)
              .backdropBlur(18)
              .constraintSize({ maxHeight: '56%' })
            Column() { this.resultPanel() }
              .backgroundColor(this.cardBg())
              .borderRadius(20)
              .backdropBlur(18)
              .layoutWeight(1)
              .padding(14)
          }
          .layoutWeight(1)
          .padding({ left: 13, right: 13, top: 8, bottom: 14 })
        }
      }
      .width('100%')
      .height('100%')
    }
    .width('100%')
    .height('100%')
  }
}
