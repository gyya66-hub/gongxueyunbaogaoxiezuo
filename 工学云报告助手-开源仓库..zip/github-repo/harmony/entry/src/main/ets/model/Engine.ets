// 报告生成引擎（与安卓 ReportEngine 同源文案与拼装逻辑）
export interface ItemDef {
  id: string;
  name: string;
  week: string[];
  month: string[];
}

export interface Headers {
  titleWeek?: string;
  titleMonth?: string;
  metaFmt?: string;
  basicMonth?: string;
  basicText?: string;
  workMonth?: string;
  gainsMonth?: string;
  issuesMonth?: string;
  improveText?: string;
  planMonth?: string;
  summaryMonth?: string;
  workWeek?: string;
  gainsWeek?: string;
  issuesWeek?: string;
  planWeek?: string;
}

export interface ContentPack {
  weekOpeners: string[];
  monthOpeners: string[];
  items: ItemDef[];
  gains: string[];
  issues: string[];
  weekPlans: string[];
  monthPlans: string[];
  monthSummary: string[];
  closings: string[];
  headers: Headers;
}

export class Config {
  unit: string = '实习单位';
  post: string = '辅助岗位';
  name: string = '';
  monthly: boolean = false;
  index: number = 1;
  itemIds: string[] = [];
}

export class Engine {
  private static fill(s: string, c: Config): string {
    return s.split('{unit}').join(c.unit)
      .split('{post}').join(c.post)
      .split('{n}').join(c.index.toString())
      .split('{name}').join(c.name)
      .split('{period}').join(c.monthly ? '月' : '周');
  }

  private static pick(arr: string[], avoid: number): string {
    if (arr.length === 0) {
      return '';
    }
    let idx: number = Math.floor(Math.random() * arr.length);
    if (arr.length > 1 && idx === avoid) {
      idx = (idx + 1) % arr.length;
    }
    return arr[idx];
  }

  static generate(p: ContentPack, c: Config): string {
    let h: Headers = p.headers;
    let lines: string[] = [];
    let title: string = h.titleWeek ?? '第{n}周实习周报';
    if (c.monthly) {
      title = h.titleMonth ?? '第{n}个月实习月报';
    }
    title = Engine.fill(title, c);
    if (c.name.length > 0) {
      title = title + '（' + c.name + '）';
    }
    lines.push(title);
    lines.push(Engine.fill(h.metaFmt ?? '实习单位：{unit}    岗位：{post}', c));
    lines.push('');

    let openers: string[] = c.monthly ? p.monthOpeners : p.weekOpeners;
    lines.push(Engine.fill(Engine.pick(openers, -1), c));
    lines.push('');

    let chosen: ItemDef[] = [];
    for (let i = 0; i < p.items.length; i++) {
      let it: ItemDef = p.items[i];
      if (c.itemIds.indexOf(it.id) >= 0) {
        chosen.push(it);
      }
    }
    if (chosen.length === 0) {
      chosen = p.items.slice(0, Math.min(3, p.items.length));
    }

    if (c.monthly) {
      lines.push(h.basicMonth ?? '一、实习基本情况');
      lines.push(Engine.fill(h.basicText ??
        '本月实习单位为{unit}，实习岗位为{post}，实习时间为第{n}个月。本月按车间安排正常出勤，遵守车间作息和安全规定，主要参与车间观摩学习和辅助岗位工作，整体实习情况稳定。', c));
      lines.push('');
      lines.push(h.workMonth ?? '二、本月主要工作内容');
      for (let i = 0; i < chosen.length; i++) {
        let it: ItemDef = chosen[i];
        lines.push((i + 1).toString() + '. ' + it.name + '：' + Engine.fill(Engine.pick(it.month, -1), c));
      }
      lines.push('');
      lines.push(h.gainsMonth ?? '三、学习与收获');
      let g1: number = Math.floor(Math.random() * p.gains.length);
      lines.push(Engine.fill(p.gains[g1], c));
      if (p.gains.length > 1) {
        let g2: number = (g1 + 1 + Math.floor(Math.random() * (p.gains.length - 1))) % p.gains.length;
        lines.push(Engine.fill(p.gains[g2], c));
      }
      lines.push('');
      lines.push(h.issuesMonth ?? '四、存在的不足与改进方向');
      lines.push(Engine.fill(Engine.pick(p.issues, -1), c));
      lines.push(h.improveText ?? '针对以上不足，我会在后续实习中加强练习，多向师傅请教，做到操作前先确认要求、作业中按标准执行、完成后及时复核，把细节做扎实。');
      lines.push('');
      lines.push(h.planMonth ?? '五、下月实习计划');
      lines.push(Engine.fill(Engine.pick(p.monthPlans, -1), c));
      lines.push('');
      lines.push(h.summaryMonth ?? '六、实习总结');
      lines.push(Engine.fill(Engine.pick(p.monthSummary, -1), c));
      lines.push('');
    } else {
      lines.push(h.workWeek ?? '一、本周主要工作内容');
      for (let i = 0; i < chosen.length; i++) {
        let it: ItemDef = chosen[i];
        lines.push((i + 1).toString() + '. ' + it.name + '：' + Engine.fill(Engine.pick(it.week, -1), c));
      }
      lines.push('');
      lines.push(h.gainsWeek ?? '二、学习与收获');
      lines.push(Engine.fill(Engine.pick(p.gains, -1), c));
      lines.push('');
      lines.push(h.issuesWeek ?? '三、存在的不足');
      lines.push(Engine.fill(Engine.pick(p.issues, -1), c));
      lines.push('');
      lines.push(h.planWeek ?? '四、下周计划');
      lines.push(Engine.fill(Engine.pick(p.weekPlans, -1), c));
      lines.push('');
    }
    lines.push(Engine.fill(Engine.pick(p.closings, -1), c));
    return Engine.cleanup(lines.join('\n'));
  }

  private static cleanup(s: string): string {
    return s.split('岗岗位').join('岗位')
      .split('岗位岗位').join('岗位')
      .split('单位单位').join('单位')
      .split('，，').join('，')
      .split('。。').join('。');
  }

  static charCount(s: string): number {
    let n: number = 0;
    for (let i = 0; i < s.length; i++) {
      let ch: string = s.charAt(i);
      if (ch === ' ' || ch === '\n' || ch === '\r' || ch === '\t') {
        continue;
      }
      n++;
    }
    return n;
  }

  static fileOf(lang: string): string {
    if (lang === 'zh-Hant') {
      return 'content_zh-Hant.json';
    }
    if (lang === 'en') {
      return 'content_en.json';
    }
    if (lang === 'ru') {
      return 'content_ru.json';
    }
    if (lang === 'ja') {
      return 'content_ja.json';
    }
    if (lang === 'ko') {
      return 'content_ko.json';
    }
    return 'content.json';
  }
}
