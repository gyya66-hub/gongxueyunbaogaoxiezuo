
(function(){
  var ua=navigator.userAgent||'';
  var mobile=/Android|iPhone|iPad|iPod|HarmonyOS|Windows Phone|BlackBerry|Mobile Safari|MicroMessenger|QQBrowser\/.*Mobile/i.test(ua);
  var touchOnly=('ontouchstart' in window) && Math.min(screen.width||9999,screen.height||9999)<700 && !/Windows NT|Macintosh|X11|Linux x86/i.test(ua);
  if(mobile||touchOnly){
    var mv=document.createElement('meta'); mv.name='viewport'; mv.content='width=device-width,initial-scale=1,maximum-scale=1';
    document.head.appendChild(mv);
    document.documentElement.classList.add('pc-blocked');
  }
})();
