#include <windows.h>
#include <stdio.h>
#include <shlobj.h>
#include "app_html.h"

/* 工学云报告助手 · 桌面启动器
   把内嵌的网页应用写到 %LOCALAPPDATA% 下，再用默认浏览器打开。 */
int main(void) {
    char base[MAX_PATH] = {0};
    char dir[MAX_PATH] = {0};
    char path[MAX_PATH] = {0};

    const char *local = getenv("LOCALAPPDATA");
    if (local && *local) {
        _snprintf(base, sizeof(base), "%s", local);
    } else {
        _snprintf(base, sizeof(base), "%s", ".");
    }

    _snprintf(dir, sizeof(dir), "%s\\GongXueYunReport", base);
    CreateDirectoryA(dir, NULL);
    _snprintf(path, sizeof(path), "%s\\index.html", dir);

    FILE *f = fopen(path, "wb");
    if (!f) {
        MessageBoxA(NULL, "无法写入临时目录，请检查权限或磁盘空间。", "工学云报告助手", MB_ICONERROR);
        return 1;
    }
    fwrite(APP_HTML, 1, APP_HTML_LEN, f);
    fclose(f);

    ShellExecuteA(NULL, "open", path, NULL, NULL, SW_SHOWNORMAL);
    return 0;
}
