// !$*UTF8*$!
{
	archiveVersion = 1;
	classes = {
	};
	objectVersion = 56;
	objects = {
__BUILDFILES__

__FILEREFS__
		__PRODREF__ /* app */ = {isa = PBXFileReference; explicitFileType = wrapper.application; includeInIndex = 0; path = "工学云报告助手.app"; sourceTree = BUILT_PRODUCTS_DIR; };
		__MAINGROUP__ = {isa = PBXGroup; children = (
			__PRODGROUP__ /* Products */,
			__APPGROUP__ /* GongXueYunReport */,
		); sourceTree = "<group>"; };
		__PRODGROUP__ /* Products */ = {isa = PBXGroup; children = (
			__PRODREF__ /* app */,
		); name = Products; sourceTree = "<group>"; };
		__APPGROUP__ /* GongXueYunReport */ = {isa = PBXGroup; children = (
__SWIFTREFS__
			__ASSETSREF__ /* Assets.xcassets */,
			__INFOREF__ /* Info.plist */,
			__RESGROUP__ /* Resources */,
		); path = GongXueYunReport; sourceTree = "<group>"; };
		__RESGROUP__ /* Resources */ = {isa = PBXGroup; children = (
__RESREFS__
		); path = Resources; sourceTree = "<group>"; };
		__TARGET__ /* GongXueYunReport */ = {isa = PBXNativeTarget; buildConfigurationList = __TARGETCFGLIST__; buildPhases = (
			__SOURCESPHASE__,
			__FRAMEWORKSPHASE__,
			__RESOURCESPHASE__,
		); buildRules = (
		); dependencies = (
		); name = GongXueYunReport; productName = GongXueYunReport; productReference = __PRODREF__; productType = "com.apple.product-type.application"; };
		__PROJECT__ /* Project object */ = {isa = PBXProject; attributes = {
			BuildIndependentTargetsInParallel = 1;
			LastSwiftUpdateCheck = 1400;
			LastUpgradeCheck = 1400;
		}; buildConfigurationList = __PROJCFGLIST__; compatibilityVersion = "Xcode 14.0"; developmentRegion = "zh-Hans"; hasScannedForEncodings = 0; knownRegions = (
			en,
			Base,
			"zh-Hans",
		); mainGroup = __MAINGROUP__; productRefGroup = __PRODGROUP__; projectDirPath = ""; projectRoot = ""; targets = (
			__TARGET__,
		); };
		__SOURCESPHASE__ = {isa = PBXSourcesBuildPhase; buildActionMask = 2147483647; files = (
__SRCBUILD__
		); runOnlyForDeploymentPostprocessing = 0; };
		__RESOURCESPHASE__ = {isa = PBXResourcesBuildPhase; buildActionMask = 2147483647; files = (
__RESBUILD__
		); runOnlyForDeploymentPostprocessing = 0; };
		__FRAMEWORKSPHASE__ = {isa = PBXFrameworksBuildPhase; buildActionMask = 2147483647; files = (
		); runOnlyForDeploymentPostprocessing = 0; };
		__PROJCFGLIST__ = {isa = XCConfigurationList; buildConfigurations = (
			__PROJDEBUG__,
			__PROJRELEASE__,
		); defaultConfigurationIsVisible = 0; defaultConfigurationName = Release; };
		__TARGETCFGLIST__ = {isa = XCConfigurationList; buildConfigurations = (
			__TGTDEBUG__,
			__TGTRELEASE__,
		); defaultConfigurationIsVisible = 0; defaultConfigurationName = Release; };
		__PROJDEBUG__ = {isa = XCBuildConfiguration; buildSettings = {
			ALWAYS_SEARCH_USER_PATHS = NO;
			CLANG_ENABLE_MODULES = YES;
			IPHONEOS_DEPLOYMENT_TARGET = 15.0;
			ONLY_ACTIVE_ARCH = YES;
			SDKROOT = iphoneos;
			SWIFT_OPTIMIZATION_LEVEL = "-Onone";
		}; name = Debug; };
		__PROJRELEASE__ = {isa = XCBuildConfiguration; buildSettings = {
			ALWAYS_SEARCH_USER_PATHS = NO;
			CLANG_ENABLE_MODULES = YES;
			IPHONEOS_DEPLOYMENT_TARGET = 15.0;
			SDKROOT = iphoneos;
			SWIFT_COMPILATION_MODE = wholemodule;
			VALIDATE_PRODUCT = YES;
		}; name = Release; };
		__TGTDEBUG__ = {isa = XCBuildConfiguration; buildSettings = {
			ASSETCATALOG_COMPILER_APPICON_NAME = AppIcon;
			CODE_SIGN_STYLE = Automatic;
			CURRENT_PROJECT_VERSION = 1;
			GENERATE_INFOPLIST_FILE = NO;
			INFOPLIST_FILE = GongXueYunReport/Info.plist;
			LD_RUNPATH_SEARCH_PATHS = (
				"$(inherited)",
				"@executable_path/Frameworks",
			);
			MARKETING_VERSION = 1.0;
			PRODUCT_BUNDLE_IDENTIFIER = com.lc.reporthelper.ios;
			PRODUCT_NAME = "工学云报告助手";
			SWIFT_VERSION = 5.0;
			TARGETED_DEVICE_FAMILY = "1,2";
		}; name = Debug; };
		__TGTRELEASE__ = {isa = XCBuildConfiguration; buildSettings = {
			ASSETCATALOG_COMPILER_APPICON_NAME = AppIcon;
			CODE_SIGN_STYLE = Automatic;
			CURRENT_PROJECT_VERSION = 1;
			GENERATE_INFOPLIST_FILE = NO;
			INFOPLIST_FILE = GongXueYunReport/Info.plist;
			LD_RUNPATH_SEARCH_PATHS = (
				"$(inherited)",
				"@executable_path/Frameworks",
			);
			MARKETING_VERSION = 1.0;
			PRODUCT_BUNDLE_IDENTIFIER = com.lc.reporthelper.ios;
			PRODUCT_NAME = "工学云报告助手";
			SWIFT_VERSION = 5.0;
			TARGETED_DEVICE_FAMILY = "1,2";
		}; name = Release; };
	};
	rootObject = __PROJECT__ /* Project object */;
}
