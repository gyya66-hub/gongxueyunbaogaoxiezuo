# 工学云报告助手 · iOS 1.0（编译说明）

## 目录结构
```
GongXueYunReport.xcodeproj/       Xcode 工程（双击打开）
GongXueYunReport/
  GXYApp.swift                   入口
  ContentView.swift              界面（iPhone 单列 / iPad 双列自动切换）
  Model.swift                    数据、五语言、报告生成
  Info.plist                     版本 1.0、最低 iOS 15、支持 iPhone+iPad
  Assets.xcassets/               图标全家桶 + 背景图 + Logo
  Resources/                     五套报告文案库（简/繁/英/俄/日）+ 界面词条
project.yml                      没装 Xcode 工程时用 XcodeGen 重建
```

## 方式一：直接打开（推荐）
1. Mac 上双击 `GongXueYunReport.xcodeproj`
2. 选中左侧项目 → Signing & Capabilities → Team 选你自己的 Apple ID
   （免费 Apple ID 也行，只是证书 7 天有效）
3. Bundle Identifier 若冲突，改成 `com.你的名字.reporthelper`
4. 顶部设备选你的 iPhone 或 iPad，点 ▶ 运行
5. 真机首次运行需在 iPhone 设置 → 通用 → VPN与设备管理 里信任证书

## 方式二：工程打不开就重建（2 分钟）
1. `brew install xcodegen`
2. 在本目录执行 `xcodegen generate`
3. 打开生成的 `GongXueYunReport.xcodeproj`，同上设置签名

## 方式三：手动新建工程（最保险）
1. Xcode → New Project → iOS → App，Interface 选 SwiftUI，名字 GongXueYunReport
2. 删掉自带的 ContentView.swift 和 Assets 里的默认 AppIcon 图
3. 把本目录 `GongXueYunReport/` 下的 3 个 .swift、Assets.xcassets、Resources 文件夹拖进工程（勾 Copy items if needed）
4. Info.plist：把 MinimumOSVersion 设 15.0，Targeted Device Family 勾 iPhone + iPad
5. 运行

## 已实现（1.0 → 1.1 同步安卓）
- 生成周报/月报 → 自动复制到剪贴板 → 点「打开工学云」跳 https://p3.gongxueyun.com/login
- 1.1 同步安卓 v2.2：工作内容 22 项、勾选上限 8 项、字数提示（周报850-950/月报1100-1300）、单位岗位空值拦截、正文手动编辑、分享面板、AI 插画背景（浅/深两套）
- 五语言：简体 / 繁体 / 英语 / 俄语 / 日语，界面 + 报告正文都换（全离线，文案库在包里）
- 语言菜单统一简体中文标注（跟随系统语言/简体中文/繁体中文/英语/俄语/日语）
- 主题三档：跟随系统 / 浅色 / 深色，磨砂玻璃卡片
- iPhone 单列；iPad（regular size class）自动左右两栏：左边设置、右边结果
- 设置项、勾选的工作内容都存在本机，重启保留

## 还没做（后面完善）
- 服务器检查更新（iOS 侧要跳 App Store 或 TestFlight，规则和安卓不同）
- 历史记录列表、导出 txt、分享面板
- 上架所需的隐私清单、App 审核文案
