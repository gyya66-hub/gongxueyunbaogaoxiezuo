import Foundation
import SwiftUI
import UIKit

// MARK: - 语言
enum Lang: String, CaseIterable, Identifiable {
    case system, hans, hant, en, ru, ja, ko
    var id: String { rawValue }
    // 语言菜单统一用简体中文标注
    var label: String {
        switch self {
        case .system: return "跟随系统语言"
        case .hans:   return "简体中文"
        case .hant:   return "繁体中文"
        case .en:     return "英语"
        case .ru:     return "俄语"
        case .ja:     return "日语"
        case .ko:     return "韩语"
        }
    }
    var contentFile: String {
        switch self {
        case .system, .hans: return "content"
        case .hant: return "content_zh-Hant"
        case .en:   return "content_en"
        case .ru:   return "content_ru"
        case .ja:   return "content_ja"
        case .ko:   return "content_ko"
        }
    }
    static func resolved(_ l: Lang) -> Lang {
        if l != .system { return l }
        let code = Locale.preferredLanguages.first ?? "zh-Hans"
        if code.hasPrefix("zh-Hant") || code.hasPrefix("zh-HK") || code.hasPrefix("zh-TW") { return .hant }
        if code.hasPrefix("zh") { return .hans }
        if code.hasPrefix("ru") { return .ru }
        if code.hasPrefix("ja") { return .ja }
        if code.hasPrefix("ko") { return .ko }
        if code.hasPrefix("en") { return .en }
        return .hans
    }
}

enum ThemeMode: String, CaseIterable, Identifiable {
    case system, light, dark
    var id: String { rawValue }
    var label: String {
        switch self {
        case .system: return "跟随系统"
        case .light:  return "浅色"
        case .dark:   return "深色"
        }
    }
    var colorScheme: ColorScheme? {
        switch self {
        case .system: return nil
        case .light:  return .light
        case .dark:   return .dark
        }
    }
}

// MARK: - 内容库
struct WorkItem: Codable, Identifiable {
    let id: String
    let name: String
    let week: [String]
    let month: [String]
}

struct Headers: Codable {
    let titleWeek: String
    let titleMonth: String
    let metaFmt: String
    let workWeek: String
    let gainsWeek: String
    let issuesWeek: String
    let planWeek: String
    let basicMonth: String
    let workMonth: String
    let gainsMonth: String
    let issuesMonth: String
    let planMonth: String
    let summaryMonth: String
    let basicText: String
    let improveText: String
}

struct ContentPack: Codable {
    let weekOpeners: [String]
    let monthOpeners: [String]
    let items: [WorkItem]
    let gains: [String]
    let issues: [String]
    let weekPlans: [String]
    let monthPlans: [String]
    let monthSummary: [String]
    let closings: [String]
    let headers: Headers
}

// MARK: - App 状态
final class AppModel: ObservableObject {
    @Published var lang: Lang { didSet { persist("lang", lang.rawValue) } }
    @Published var theme: ThemeMode { didSet { persist("theme", theme.rawValue) } }
    @Published var monthly: Bool { didSet { persist("monthly", monthly ? "1" : "0") } }
    @Published var index: Int { didSet { persist("index", String(index)) } }
    @Published var unit: String { didSet { persist("unit", unit) } }
    @Published var post: String { didSet { persist("post", post) } }
    @Published var selected: Set<String> { didSet { persist("selected", selected.joined(separator: ",")) } }
    @Published var report: String = ""
    @Published var copied: Bool = false
    @Published var notice: String = ""

    private var packs: [String: ContentPack] = [:]
    private var uiTables: [String: [String: String]] = [:]

    init() {
        let d = UserDefaults.standard
        lang = Lang(rawValue: d.string(forKey: "gxy_lang") ?? "") ?? .system
        theme = ThemeMode(rawValue: d.string(forKey: "gxy_theme") ?? "") ?? .system
        monthly = d.bool(forKey: "gxy_monthly")
        index = max(1, d.integer(forKey: "gxy_index"))
        unit = d.string(forKey: "gxy_unit") ?? "合肥中创新航科技有限公司"
        post = d.string(forKey: "gxy_post") ?? "汽车制造辅助岗"
        let sel = d.string(forKey: "gxy_selected") ?? ""
        selected = sel.isEmpty ? ["observe", "assist", "check"] : Set(sel.split(separator: ",").map(String.init))
        if selected.isEmpty { selected = ["observe", "assist", "check"] }
        loadUi()
    }

    private func persist(_ k: String, _ v: String) { UserDefaults.standard.set(v, forKey: "gxy_" + k) }

    // MARK: 界面词条
    private func loadUi() {
        guard let url = Bundle.main.url(forResource: "ui", withExtension: "json"),
              let data = try? Data(contentsOf: url),
              let raw = try? JSONSerialization.jsonObject(with: data) as? [String: [String: String]] else { return }
        for (code, table) in raw {
            var t: [String: String] = [:]
            for (k, v) in table { t[k] = v }
            uiTables[code] = t
        }
    }

    func t(_ zh: String) -> String {
        let code: String
        switch Lang.resolved(lang) {
        case .hant: code = "zh-Hant"
        case .en: code = "en"
        case .ru: code = "ru"
        case .ja: code = "ja"
        case .ko: code = "ko"
        default: return zh
        }
        if let v = uiTables[code]?[zh], !v.isEmpty { return v }
        return zh
    }

    // MARK: 内容库
    func pack() -> ContentPack? {
        let key = Lang.resolved(lang).contentFile
        if let p = packs[key] { return p }
        guard let url = Bundle.main.url(forResource: key, withExtension: "json"),
              let data = try? Data(contentsOf: url),
              let p = try? JSONDecoder().decode(ContentPack.self, from: data) else { return nil }
        packs[key] = p
        return p
    }

    var allItems: [WorkItem] { pack()?.items ?? [] }

    // MARK: 生成
    func generate() {
        guard let c = pack() else { report = "内容库加载失败"; return }
        if unit.trimmingCharacters(in: .whitespaces).isEmpty || post.trimmingCharacters(in: .whitespaces).isEmpty {
            notice = "实习单位和岗位不要留空，学校可能会核对"
            return
        }
        notice = ""
        if selected.count > 8 {
            notice = "最多勾选 8 项，太多了正文会变成罗列"
            return
        }
        var rnd = SystemRandomNumberGenerator()
        func pick(_ a: [String]) -> String { a.isEmpty ? "" : a[Int.random(in: 0..<a.count, using: &rnd)] }
        let h = c.headers
        var out = ""
        let chosen = c.items.filter { selected.contains($0.id) }
        let list = chosen.isEmpty ? Array(c.items.prefix(3)) : chosen

        func fill(_ s: String) -> String {
            s.replacingOccurrences(of: "{unit}", with: unit)
             .replacingOccurrences(of: "{post}", with: post)
             .replacingOccurrences(of: "{n}", with: String(index))
             .replacingOccurrences(of: "{name}", with: "")
             .replacingOccurrences(of: "{period}", with: monthly ? "\(index)个月" : "第\(index)周")
        }
        out += fill(pick(monthly ? c.monthOpeners : c.weekOpeners)) + "\n\n"

        if monthly {
            out += h.basicMonth + "\n"
            out += fill(h.basicText) + "\n\n"
            out += h.workMonth + "\n"
            for (i, it) in list.enumerated() {
                out += "\(i + 1). \(it.name)：" + fill(pick(it.month)) + "\n"
            }
            out += "\n"
            out += h.gainsMonth + "\n" + fill(pick(c.gains)) + "\n\n"
            out += h.issuesMonth + "\n" + fill(pick(c.issues)) + "\n"
            out += fill(h.improveText) + "\n\n"
            out += h.planMonth + "\n" + fill(pick(c.monthPlans)) + "\n\n"
            out += h.summaryMonth + "\n" + fill(pick(c.monthSummary)) + "\n\n"
        } else {
            out += h.workWeek + "\n"
            for (i, it) in list.enumerated() {
                out += "\(i + 1). \(it.name)：" + fill(pick(it.week)) + "\n"
            }
            out += "\n"
            out += h.gainsWeek + "\n" + fill(pick(c.gains)) + "\n\n"
            out += h.issuesWeek + "\n" + fill(pick(c.issues)) + "\n\n"
            out += h.planWeek + "\n" + fill(pick(c.weekPlans)) + "\n\n"
        }
        out += fill(pick(c.closings))
        report = out.trimmingCharacters(in: .whitespacesAndNewlines)
        copied = false
    }

    func copy() {
        UIPasteboard.general.string = report
        copied = true
    }

    func openGongxueyun() {
        guard let url = URL(string: "https://p3.gongxueyun.com/login") else { return }
        UIApplication.shared.open(url)
    }
}
