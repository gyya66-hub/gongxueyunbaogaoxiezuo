# 上传到 GitHub（三种方式，选一种）

仓库已在本目录初始化完成（已有 1 个提交），直接推送即可。

## 方式一：GitHub Desktop（最简单，推荐）
1. 装 GitHub Desktop，登录账号
2. File → Add local repository → 选本文件夹 `github-repo`
3. 右上角 Publish repository → 填名字 `gxy-report-helper` → **取消勾选 Keep this code private**（要开源就公开）→ Publish

## 方式二：命令行 + 个人令牌（Token）
1. GitHub → Settings → Developer settings → Personal access tokens → Generate new token
   勾选权限 `repo`，生成后复制（只显示一次）
2. 在 GitHub 网页新建空仓库（不要勾 README/gitignore）
3. 执行：
```bash
cd github-repo
git remote add origin https://github.com/你的用户名/gxy-report-helper.git
git branch -M main
git push -u origin main
# 用户名填你的 GitHub 名，密码位置粘贴 Token
```

## 方式三：网页上传
仓库页 → Add file → Upload files → 把整个文件夹内容拖进去（`tools`、`docs` 可分开传）
注意：网页上传不支持隐藏目录 `.github`，iOS 流水线要单独用 Desktop 或命令行补传。

## 上传后建议做的三件事
1. Settings → 右侧 About → 填 Description 和 Topics（android, ios, internship, report-generator）
2. 在 Releases 里发 v2.2，附上编译好的 apk（这样别人不用自己编）
3. 若想接受他人贡献，加一个 `CONTRIBUTING.md` 说明代码风格与 PR 流程

## 已做过的安全清理
- 签名密钥（keystore）、apk/exe 等构建产物已写进 `.gitignore`，不会上传
- 文档里的真实局域网 IP（192.168.10.x）已替换为示例地址 192.168.1.x
- 服务器密钥密码替换为占位符
