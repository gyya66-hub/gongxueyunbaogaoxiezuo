# 用电脑（Windows）打 iOS 的 ipa 包

Windows 上没有 Xcode，装不了 iOS 编译器。但可以**用 GitHub 免费的 macOS 服务器编译**，
最后在 Windows 上用 Sideloadly 重签名装到 iPhone。全程不用买 Mac。

---
## 第一步：把工程传到 GitHub（约 5 分钟）
1. 打开 github.com 注册账号（免费）
2. 右上角 + → New repository → 名字随意（如 `gxy-ios`）→ 选 **Private** → Create
3. 解压本 zip，把整个 `GongXueYunReport` 文件夹里的内容上传：
   网页版仓库 → Add file → Upload files → 把 `GongXueYunReport.xcodeproj`、
   `GongXueYunReport` 文件夹、`.github` 文件夹、`project.yml` 一起拖进去 → Commit
   （`.github` 是隐藏目录，网页拖拽可能看不到；用 GitHub Desktop 客户端更稳）

## 第二步：让它自己编译（约 3 分钟）
1. 仓库页面点 **Actions** → 左侧 `build-ios-ipa` → 右侧 **Run workflow** → Run
2. 等 2–5 分钟，绿勾表示成功
3. 点进这次运行，页面底部 **Artifacts** 下载 `GongXueYunReport-ipa`
4. 解压得到 `GongXueYunReport-unsigned.ipa`

> 失败的话下载 `build-log`，把日志末尾报错发我，我改代码，这是最快迭代方式。

## 第三步：Windows 上签名装到 iPhone
未签名的 ipa 不能直接装，要用你的 Apple ID 现场签一次：

1. 装 **Sideloadly**（sideloadly.io，免费）
2. 电脑装 **iTunes**（微软商店版即可，提供驱动）+ 数据线连 iPhone，手机点"信任"
3. 打开 Sideloadly，把 `GongXueYunReport-unsigned.ipa` 拖进 IPA 框
4. Apple ID 填你的 Apple ID，点 Start
5. 首次装好后：iPhone 设置 → 通用 → VPN与设备管理 → 信任你的开发者证书
6. 打开 App 即可用

**限制**：免费 Apple ID 签的 App **7 天到期**，到期用 Sideloadly 再点一次 Start 续签
（数据不丢）。想一年不用管，需要 Apple Developer 会员（688 元/年）。

---
## 常见问题
**Q: 能不能不用 GitHub，直接 Windows 编译？**
不能。iOS 的编译器、SDK、签名工具链只在 macOS 上提供，Windows 上没有合法实现。
GitHub Actions 的 `macos-14` 就是一台云端 Mac，这是免费且合规的替代方案。

**Q: 免费额度够吗？**
公开仓库 Actions 完全免费；私有仓库每月 2000 分钟免费额度，一次编译约 3–5 分钟，
够用几百次。

**Q: 想要长期给别人用？**
走 TestFlight：Apple Developer 会员 → Xcode/GitHub Actions 导出签名包 →
App Store Connect 上传 → 邀请测试者（有效期 90 天一轮）。
