# 参与修改

欢迎改文案、加语言、修 bug、改界面。这个项目没有复杂架构，改起来门槛很低。

## 三种最常见的修改

### 1. 改 / 加工作内容（最常改）
文件：`android/assets/content.json`
```json
{ "id": "observe", "name": "车间观摩学习",
  "week":  ["本周……", "……"],
  "month": ["本月……"] }
```
- `id` 用英文小写，全局唯一
- `week` 放 4–6 条周报文案，`month` 放 3–5 条月报文案
- 文案里可用占位符：`{unit}` `{post}` `{n}` `{period}`
- 改完执行 `python3 tools/build.py` 生成繁体版，再执行
  `LANGS=en,ru,ja,ko python3 tools/translate.py` 补其余语言（会走机器翻译，需联网）
- 五套 `content_*.json` 的 `items` 数量必须一致，否则切语言会缺项

### 2. 加一门语言
1. 准备 `android/assets/content_xx.json`（结构照抄 `content_en.json`）
2. 在 `android/assets/i18n/ui.json` 加一个 `"xx": { "中文原句": "译文" }` 段
3. 四处登记语言：
   - `android/java/.../L.java`（`systemLang()`、`label()`）
   - `android/java/.../MainActivity.java`（`pickLanguage()` 的 values/labels）
   - `android/java/.../ReportEngine.java`（内容库文件名映射）
   - `desktop/app.tpl.html`（下拉选项 + `DATA_XX` 常量 + `resolveLang`）
   - `ios/.../Model.swift`（`Lang` 枚举）
   - `harmony/.../Engine.ets` 与 `pages/Index.ets`（文件映射与语言数组）

### 3. 改界面 / 主题
- 网页/电脑：`desktop/app.tpl.html` 里的 CSS 变量（`--img` `--veil` `--text` 等），改完跑 `scripts/build_web.sh`
- 安卓：`android/java/.../MainActivity.java` 的 `buildUi()`，颜色在 `android/res/values/colors.xml`
- iOS：`ios/.../ContentView.swift`
- 鸿蒙：`harmony/entry/src/main/ets/pages/Index.ets`

## 提交前自查
- [ ] 安卓能编译（`bash scripts/build_apk.sh`）
- [ ] 网页能打开且六种语言都能切（`bash scripts/build_web.sh` 后打开 `desktop/app.html`）
- [ ] 没有把 keystore / apk / exe / 个人单位名提交上来（`.gitignore` 已挡，提交前 `git status` 扫一眼）
- [ ] 改文案的，检查 `{unit}` `{post}` 占位符没被翻译掉

## PR 建议
- 一个 PR 只做一件事，说明改了什么、为什么
- 改文案的请贴一段生成结果示例，方便 review

## 不要提交
签名证书、打包产物、包含真实公司名/学校名/个人姓名的内容。
