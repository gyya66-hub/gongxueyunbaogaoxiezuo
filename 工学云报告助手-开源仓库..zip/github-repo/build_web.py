#!/usr/bin/env python3
"""把 content/*.json 与底图注入 app.tpl.html，生成 app.html 与 app_html.h"""
import base64, os, json

HERE = os.path.dirname(os.path.abspath(__file__))
ASSETS = os.path.join(HERE, 'android', 'assets')
TPL = os.path.join(HERE, 'desktop', 'app.tpl.html')

def uri(path):
    return 'data:image/jpeg;base64,' + base64.b64encode(open(path, 'rb').read()).decode()

tpl = open(TPL, encoding='utf-8').read()
files = {
    '/*__CONTENT__*/': 'content.json',
    '/*__CONTENT_HANT__*/': 'content_zh-Hant.json',
    '/*__CONTENT_EN__*/': 'content_en.json',
    '/*__CONTENT_RU__*/': 'content_ru.json',
    '/*__CONTENT_JA__*/': 'content_ja.json',
    '/*__CONTENT_KO__*/': 'content_ko.json',
    '/*__UI__*/': 'i18n/ui.json',
}
for key, name in files.items():
    tpl = tpl.replace(key, open(os.path.join(ASSETS, name), encoding='utf-8').read())
tpl = tpl.replace('__BG_LIGHT__', uri(os.path.join(HERE, 'android', 'res', 'drawable-nodpi', 'bg_light.jpg')))
tpl = tpl.replace('__BG_DARK__', uri(os.path.join(HERE, 'android', 'res', 'drawable-nodpi', 'bg_dark.jpg')))

out = os.path.join(HERE, 'desktop', 'app.html')
open(out, 'w', encoding='utf-8').write(tpl)
data = tpl.encode('utf-8')
with open(os.path.join(HERE, 'desktop', 'app_html.h'), 'w', encoding='utf-8') as f:
    f.write('static const unsigned char APP_HTML[] = {\n')
    for i in range(0, len(data), 16):
        f.write(','.join('0x%02x' % b for b in data[i:i+16]) + ',\n')
    f.write('};\nstatic const unsigned int APP_HTML_LEN = %d;\n' % len(data))
print('app.html', len(data), 'bytes')
