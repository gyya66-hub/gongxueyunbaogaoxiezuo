#!/usr/bin/env bash
# Windows 单文件 exe（需 mingw-w64；在 Linux 上交叉编译）
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT/desktop"
python3 "$ROOT/build_web.py"
i686-w64-mingw32-windres app.rc -O coff -o app.res
i686-w64-mingw32-gcc -O2 -mwindows launcher.c app.res -o GongXueYunReport.exe -s
echo "产物：$ROOT/desktop/GongXueYunReport.exe"
