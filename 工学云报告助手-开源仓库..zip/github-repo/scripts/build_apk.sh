#!/usr/bin/env bash
# 构建安卓 apk（不依赖 Gradle，直接用 SDK build-tools）
# 用法：先设环境变量，再跑本脚本
#   export ANDROID_HOME=~/Android/Sdk
#   bash scripts/build_apk.sh
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SRC="$ROOT/android"
BT="$(ls -d "$ANDROID_HOME"/build-tools/*/ | sort -V | tail -1)"
AJ="$ANDROID_HOME/platforms/android-33/android.jar"
OUT="$ROOT/build/apk"
VER_CODE="${VER_CODE:-17}"
VER_NAME="${VER_NAME:-2.5}"
KS="${KEYSTORE:-$HOME/.android/debug.keystore}"

[ -d "$SRC" ] || { echo "找不到 android 目录"; exit 1; }
[ -f "$AJ" ]  || { echo "缺少 android.jar：请在 SDK Manager 装 Android 13 (API 33)"; exit 1; }

rm -rf "$OUT" && mkdir -p "$OUT/gen" "$OUT/classes" "$OUT/dex"

cd "$SRC"
"$BT/aapt2" compile --dir res -o "$OUT/res.zip"
"$BT/aapt2" link -o "$OUT/base.apk" -I "$AJ" --manifest AndroidManifest.xml \
  -R "$OUT/res.zip" --java "$OUT/gen" -A assets \
  --min-sdk-version 21 --target-sdk-version 33 --auto-add-overlay \
  --version-code "$VER_CODE" --version-name "$VER_NAME"

javac -source 8 -target 8 -bootclasspath "$AJ:$BT/core-lambda-stubs.jar" \
  -encoding UTF-8 -nowarn -d "$OUT/classes" \
  $(find java "$OUT/gen" -name '*.java')

"$BT/d8" --lib "$AJ" --min-api 21 --output "$OUT/dex" $(find "$OUT/classes" -name '*.class')

cd "$OUT"
cp base.apk app-unsigned.apk
zip -q -j app-unsigned.apk dex/classes.dex
"$BT/zipalign" -f 4 app-unsigned.apk app-aligned.apk
if [ -f "$KS" ]; then
  "$BT/apksigner" sign --ks "$KS" --ks-pass pass:"${KS_PASS:-android}" --out app.apk app-aligned.apk
else
  echo "没有 keystore，输出未签名 apk（可用 apksigner 自行签名）"
  cp app-aligned.apk app.apk
fi
echo "产物：$OUT/app.apk"
