#!/usr/bin/env bash
# 生成网页版单文件 app.html（内含内容库与底图）
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
python3 build_web.py
echo "产物：$ROOT/desktop/app.html —— 直接用浏览器打开即可"
