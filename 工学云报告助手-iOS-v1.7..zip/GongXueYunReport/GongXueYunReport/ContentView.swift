import SwiftUI

struct ContentView: View {
    @EnvironmentObject var app: AppModel
    @Environment(\.horizontalSizeClass) private var hsc
    @Environment(\.colorScheme) private var scheme
    @State private var showEdit = false
    @State private var showShare = false
    @State private var draft = ""
    @State private var edited = false
    @State private var showMsgBoard = false

    private var wide: Bool { hsc == .regular }

    var body: some View {
        ZStack {
            background
            ScrollView {
                VStack(spacing: 12) {
                    header
                    if wide {
                        HStack(alignment: .top, spacing: 14) {
                            VStack(spacing: 12) {
                                settingsCard
                                itemsCard
                                generateButton
                                moreCard
                            }
                            .frame(width: 380)
                            VStack(spacing: 12) { resultCard }
                                .frame(maxWidth: .infinity, alignment: .top)
                        }
                    } else {
                        VStack(spacing: 12) {
                            settingsCard
                            itemsCard
                            generateButton
                            resultCard
                            moreCard
                        }
                    }
                    footer
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 14)
            }
        }
        .preferredColorScheme(app.theme.colorScheme)
        .sheet(isPresented: $showEdit) {
            NavigationView {
                VStack {
                    TextEditor(text: $draft)
                        .font(.system(size: 14))
                        .padding(6)
                }
                .navigationTitle("编辑正文")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) {
                        Button("取消") { showEdit = false }
                    }
                    ToolbarItem(placement: .confirmationAction) {
                        Button("保存并复制") {
                            app.report = draft
                            app.copy()
                            edited = true
                            showEdit = false
                        }
                    }
                }
            }
        }
        .sheet(isPresented: $showShare) {
            ShareSheet(text: app.report)
        }
    }

    // MARK: 背景
    private var background: some View {
        ZStack {
            LinearGradient(colors: scheme == .dark
                           ? [Color(red: 0.05, green: 0.07, blue: 0.10), Color(red: 0.09, green: 0.11, blue: 0.16)]
                           : [Color(red: 0.86, green: 0.90, blue: 1.0), Color(red: 0.94, green: 0.93, blue: 1.0), Color(red: 1.0, green: 0.92, blue: 0.94)],
                           startPoint: .topLeading, endPoint: .bottomTrailing)
            Image(scheme == .dark ? "bg_dark" : "bg_light")
                .resizable()
                .scaledToFill()
                .opacity(scheme == .dark ? 0.9 : 0.75)
                .ignoresSafeArea()
            Circle().fill(Color(red: 0.56, green: 0.75, blue: 1.0).opacity(scheme == .dark ? 0.18 : 0.35))
                .frame(width: 420, height: 420).blur(radius: 60).offset(x: -140, y: -240)
            Circle().fill(Color(red: 1.0, green: 0.62, blue: 0.72).opacity(scheme == .dark ? 0.16 : 0.3))
                .frame(width: 380, height: 380).blur(radius: 70).offset(x: 160, y: 300)
        }
        .ignoresSafeArea()
        .sheet(isPresented: $showMsgBoard) { MsgBoardView() }
    }

    // MARK: 顶部
    private var header: some View {
        HStack(alignment: .top, spacing: 12) {
            Image("AppLogo").resizable().frame(width: 42, height: 42)
                .clipShape(RoundedRectangle(cornerRadius: 11, style: .continuous))
            VStack(alignment: .leading, spacing: 3) {
                Text(app.t("工学云报告助手")).font(.system(size: 19, weight: .bold))
                Text(app.t("离线生成 · 一键复制 · 手机电脑通用"))
                    .font(.system(size: 11.5)).foregroundColor(.secondary)
            }
            Spacer(minLength: 6)
            Menu {
                ForEach(Lang.allCases) { l in
                    Button(l.label) { app.lang = l }
                }
            } label: {
                HStack(spacing: 3) {
                    Text(app.lang == .system ? "跟随系统语言" : app.lang.label)
                        .font(.system(size: 11.5, weight: .medium))
                    Image(systemName: "chevron.down").font(.system(size: 9, weight: .semibold))
                }
                .padding(.horizontal, 10).padding(.vertical, 7)
                .background(.ultraThinMaterial, in: Capsule())
            }
            Menu {
                ForEach(ThemeMode.allCases) { m in
                    Button(m.label) { app.theme = m }
                }
            } label: {
                Image(systemName: scheme == .dark ? "moon.fill" : "sun.max.fill")
                    .font(.system(size: 13))
                    .padding(.horizontal, 10).padding(.vertical, 7)
                    .background(.ultraThinMaterial, in: Capsule())
            }
        }
    }

    // MARK: 报告设置
    private var settingsCard: some View {
        GlassCard {
            SectionTitle(text: app.t("报告设置"))
            HStack(spacing: 0) {
                segButton(app.t("周报"), active: !app.monthly) { app.monthly = false }
                segButton(app.t("月报"), active: app.monthly) { app.monthly = true }
            }
            .padding(3)
            .background(Color.primary.opacity(0.06), in: Capsule())

            HStack {
                Text(app.t("期数")).font(.system(size: 12)).foregroundColor(.secondary)
                Spacer()
                Picker("", selection: $app.index) {
                    ForEach(1...40, id: \.self) { i in
                        Text(app.monthly ? "第 \(i) 个月" : "第 \(i) 周").tag(i)
                    }
                }
                .pickerStyle(.menu)
            }
            field(app.t("实习单位"), placeholder: "合肥中创新航科技有限公司", text: $app.unit)
            field(app.t("实习岗位"), placeholder: "汽车制造辅助岗", text: $app.post)
        }
    }

    private func segButton(_ title: String, active: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 13, weight: active ? .semibold : .regular))
                .foregroundColor(active ? .white : .secondary)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 8)
                .background(active ? Color(red: 0.24, green: 0.47, blue: 0.95) : Color.clear,
                            in: Capsule())
        }
        .buttonStyle(.plain)
    }

    private func field(_ title: String, placeholder: String, text: Binding<String>) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(title).font(.system(size: 12)).foregroundColor(.secondary)
            TextField(placeholder, text: text)
                .font(.system(size: 14))
                .padding(.horizontal, 12).padding(.vertical, 10)
                .background(Color.primary.opacity(0.05), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
        }
    }

    // MARK: 工作内容
    private var itemsCard: some View {
        GlassCard {
            HStack {
                SectionTitle(text: app.t("工作内容"))
                Spacer()
                Text("已选 \(app.selected.count) 项").font(.system(size: 11)).foregroundColor(.secondary)
            }
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 96), spacing: 8)], spacing: 8) {
                ForEach(app.allItems) { it in
                    let on = app.selected.contains(it.id)
                    Button {
                        if on {
                            app.selected.remove(it.id)
                        } else {
                            if app.selected.count >= 8 { app.notice = "最多勾选 8 项，太多了正文会变成罗列"; return }
                            app.selected.insert(it.id)
                        }
                    } label: {
                        Text(it.name)
                            .font(.system(size: 12.5, weight: on ? .semibold : .regular))
                            .foregroundColor(on ? Color(red: 0.16, green: 0.38, blue: 0.86) : .secondary)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 8).padding(.horizontal, 6)
                            .background(on ? Color(red: 0.24, green: 0.47, blue: 0.95).opacity(0.14) : Color.primary.opacity(0.04),
                                        in: Capsule())
                            .overlay(Capsule().stroke(on ? Color(red: 0.24, green: 0.47, blue: 0.95).opacity(0.5) : Color.clear, lineWidth: 1))
                    }
                    .buttonStyle(.plain)
                }
            }
            Text(app.t("建议勾选本周实际做过的 3-5 项，文案会跟着变化；每次生成措辞随机组合。"))
                .font(.system(size: 11)).foregroundColor(.secondary).fixedSize(horizontal: false, vertical: true)
        }
    }

    // MARK: 生成
    private var generateButton: some View {
        Button {
            app.generate()
            app.copy()
        } label: {
            Text(app.monthly ? app.t("生成月报并复制") : app.t("生成周报并复制"))
                .font(.system(size: 16, weight: .semibold))
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 15)
                .background(LinearGradient(colors: [Color(red: 0.36, green: 0.58, blue: 1.0), Color(red: 0.20, green: 0.42, blue: 0.92)],
                                           startPoint: .topLeading, endPoint: .bottomTrailing),
                            in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                .shadow(color: Color(red: 0.2, green: 0.42, blue: 0.92).opacity(0.28), radius: 12, y: 6)
        }
        .buttonStyle(.plain)
    }

    // MARK: 结果
    private var resultCard: some View {
        GlassCard {
            HStack {
                SectionTitle(text: app.t("生成结果"))
                Spacer()
                Text(wordTip).font(.system(size: 11)).foregroundColor(.secondary)
            }
            if app.report.isEmpty {
                Text(app.t("先生成一份报告"))
                    .font(.system(size: 13)).foregroundColor(.secondary)
                    .frame(maxWidth: .infinity, minHeight: wide ? 420 : 200)
                    .multilineTextAlignment(.center)
            } else {
                ScrollView {
                    Text(app.report)
                        .font(.system(size: 14))
                        .lineSpacing(6)
                        .textSelection(.enabled)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(12)
                }
                .frame(minHeight: wide ? 460 : 260, maxHeight: wide ? 640 : 380)
                .background(Color.primary.opacity(0.04), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            }
            HStack(spacing: 8) {
                smallButton(app.t("复制全文"), system: "doc.on.doc") { app.copy() }
                smallButton("编辑", system: "square.and.pencil") { draft = app.report; showEdit = true }
                smallButton("分享", system: "square.and.arrow.up") { showShare = true }
                smallButton(app.t("换一版"), system: "arrow.triangle.2.circlepath") { app.generate() }
                smallButton(app.t("打开工学云"), system: "arrow.up.right.square") { app.openGongxueyun() }
            }
            if !app.notice.isEmpty {
                Text(app.notice).font(.system(size: 11)).foregroundColor(.orange)
            }
            if app.copied {
                Text(app.t("已复制，去工学云长按粘贴即可"))
                    .font(.system(size: 11)).foregroundColor(Color(red: 0.13, green: 0.55, blue: 0.34))
            }
        }
    }

    private func smallButton(_ title: String, system: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 4) {
                Image(systemName: system).font(.system(size: 11))
                Text(title).font(.system(size: 12, weight: .medium))
            }
            .padding(.horizontal, 11).padding(.vertical, 8)
            .background(.ultraThinMaterial, in: Capsule())
        }
        .buttonStyle(.plain)
    }

    private var wordTip: String {
        let n = app.report.count
        if n == 0 { return "0 字" }
        if edited { return "\(n) 字 · 已手动编辑" }
        let lo = app.monthly ? 1100 : 850, hi = app.monthly ? 1300 : 950
        let tip = n < lo ? "偏短，建议再生成一版" : (n > hi ? "偏长，可手动删减" : "字数合适")
        return "\(n) 字 · \(tip)"
    }

    // MARK: 更多
    private var moreCard: some View {
        GlassCard {
            SectionTitle(text: app.t("更多"))
            row(icon: "arrow.up.right.square", title: app.t("打开工学云"), value: "") { app.openGongxueyun() }
            row(icon: "globe", title: app.t("语言"), value: app.lang == .system ? "跟随系统语言" : app.lang.label) {}
            row(icon: "circle.leverage", title: app.t("外观主题"), value: app.theme.label) {}
            Button {
                showMsgBoard = true
            } label: {
                HStack(spacing: 10) {
                    Image(systemName: "bubble.left.and.text.bubble.right")
                        .font(.system(size: 13))
                        .foregroundColor(Color(red: 0.24, green: 0.47, blue: 0.95))
                        .frame(width: 20)
                    Text(app.t("留言板")).font(.system(size: 13.5))
                    Spacer()
                    Text(MsgStore.countText).font(.system(size: 12)).foregroundColor(.secondary)
                }
                .padding(.vertical, 6)
            }
            .buttonStyle(.plain)
            Button {
                UIPasteboard.general.string = "1121018207"
                if let u = URL(string: "mqqapi://card/show_pslcard?src_type=internal&version=1&uin=1121018207&card_type=group&source=qrcode"), UIApplication.shared.canOpenURL(u) {
                    UIApplication.shared.open(u)
                }
            } label: {
                HStack(spacing: 10) {
                    Image(systemName: "person.2.fill")
                        .font(.system(size: 13))
                        .foregroundColor(Color(red: 0.24, green: 0.47, blue: 0.95))
                        .frame(width: 20)
                    Text("反馈群（QQ）").font(.system(size: 13.5))
                    Spacer()
                    Text("1121018207").font(.system(size: 12)).foregroundColor(.secondary)
                }
                .padding(.vertical, 6)
            }
            .buttonStyle(.plain)
            row(icon: "info.circle", title: app.t("关于本工具"), value: "v1.5") {}
        }
    }

    private func row(icon: String, title: String, value: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 10) {
                Image(systemName: icon).font(.system(size: 13)).foregroundColor(Color(red: 0.24, green: 0.47, blue: 0.95))
                    .frame(width: 20)
                Text(title).font(.system(size: 13.5))
                Spacer()
                Text(value).font(.system(size: 12)).foregroundColor(.secondary)
            }
            .padding(.vertical, 6)
        }
        .buttonStyle(.plain)
    }

    private var footer: some View {
        Text("纯本地生成，不联网、不上传、不代提交；复制后自己粘贴到工学云提交。")
            .font(.system(size: 10.5))
            .foregroundColor(.secondary)
            .multilineTextAlignment(.center)
            .padding(.top, 4)
    }
}

// MARK: - 留言板（只存本机 UserDefaults，不联网）

final class MsgStore {
    static let key = "gxy_msgs"
    struct Msg: Codable, Identifiable {
        let id = UUID()
        var t: String
        var x: String
    }
    static func load() -> [Msg] {
        guard let d = UserDefaults.standard.data(forKey: key),
              let list = try? JSONDecoder().decode([Msg].self, from: d) else { return [] }
        return list
    }
    static func save(_ list: [Msg]) {
        let capped = Array(list.prefix(50))
        if let d = try? JSONEncoder().encode(capped) { UserDefaults.standard.set(d, forKey: key) }
    }
    static var countText: String {
        let n = load().count
        return n > 0 ? "\(n) 条" : "写反馈 / 建议"
    }
}

struct MsgBoardView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var draft = ""
    @State private var msgs: [MsgStore.Msg] = MsgStore.load()

    private var stamp: String {
        let f = DateFormatter()
        f.dateFormat = "MM-dd HH:mm"
        return f.string(from: Date())
    }

    var body: some View {
        NavigationView {
            VStack(spacing: 10) {
                TextEditor(text: )
                    .frame(height: 96)
                    .padding(6)
                    .background(Color(.secondarySystemBackground))
                    .cornerRadius(12)
                    .overlay(
                        Group { if draft.isEmpty {
                            Text("写使用反馈、建议或遇到的问题（只保存在本机）")
                                .font(.system(size: 12.5)).foregroundColor(.secondary)
                                .padding(.top, 18).padding(.leading, 12)
                                .allowsHitTesting(false)
                                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
                        } }
                    )
                HStack {
                    Button("保存留言") {
                        let v = draft.trimmingCharacters(in: .whitespacesAndNewlines)
                        guard !v.isEmpty else { return }
                        msgs.insert(MsgStore.Msg(t: stamp, x: v), at: 0)
                        MsgStore.save(msgs)
                        draft = ""
                    }
                    .buttonStyle(.borderedProminent)
                    Spacer()
                    Text("共 \(msgs.count) 条").font(.system(size: 12)).foregroundColor(.secondary)
                }
                List {
                    ForEach(msgs) { m in
                        VStack(alignment: .leading, spacing: 4) {
                            Text(m.t).font(.system(size: 11)).foregroundColor(.secondary)
                            Text(m.x).font(.system(size: 13.5))
                        }
                        .padding(.vertical, 2)
                    }
                    .onDelete { idx in
                        msgs.remove(atOffsets: idx)
                        MsgStore.save(msgs)
                    }
                }
                .listStyle(.plain)
            }
            .padding(14)
            .navigationTitle("留言板")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("清空") { msgs = []; MsgStore.save(msgs) }
                        .disabled(msgs.isEmpty)
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("关闭") { dismiss() }
                }
            }
        }
        .navigationViewStyle(.stack)
    }
}

// MARK: - 组件
struct SectionTitle: View {
    let text: String
    var body: some View {
        HStack(spacing: 6) {
            Circle().fill(Color(red: 0.24, green: 0.47, blue: 0.95)).frame(width: 6, height: 6)
            Text(text).font(.system(size: 13, weight: .semibold))
        }
    }
}

struct GlassCard<Content: View>: View {
    let content: Content
    init(@ViewBuilder content: () -> Content) { self.content = content() }
    var body: some View {
        VStack(alignment: .leading, spacing: 10) { content }
            .padding(15)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous)
                .stroke(Color.white.opacity(0.35), lineWidth: 1))
            .shadow(color: Color.black.opacity(0.07), radius: 14, y: 7)
    }
}

struct ShareSheet: UIViewControllerRepresentable {
    let text: String
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: [text], applicationActivities: nil)
    }
    func updateUIViewController(_ vc: UIActivityViewController, context: Context) {}
}
